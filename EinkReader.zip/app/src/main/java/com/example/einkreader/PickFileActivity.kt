package com.example.einkreader

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.File

/** 简易文件浏览器：部分墨水屏系统没有系统文件选择器，直接调用会闪退，所以自带一个 */
class PickFileActivity : Activity() {
    private class Entry(val file: File, val label: String, val kind: Int)   // 0 上一级 1 文件夹 2 文件

    private var exts: Set<String> = emptySet()
    private var multi = false
    private var dir: File = Environment.getExternalStorageDirectory()
    private val selected = LinkedHashSet<String>()
    private var items: List<Entry> = emptyList()
    private lateinit var pathView: TextView
    private lateinit var hint: TextView
    private lateinit var confirm: TextView
    private lateinit var listView: ListView
    private val prefs by lazy { getSharedPreferences("pick", MODE_PRIVATE) }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(i: Int): Any = items[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View {
            val e = items[i]
            return TextView(this@PickFileActivity).apply {
                textSize = 19f
                setTextColor(BLACK)
                setPadding(dp(8), dp(14), dp(8), dp(14))
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.MIDDLE
                text = when (e.kind) {
                    0 -> "↑ 返回上一级"
                    1 -> "▸ ${e.label}"
                    else -> (if (multi) (if (selected.contains(e.file.path)) "■ " else "□ ") else "") +
                        e.label + "   " + size(e.file.length())
                }
                if (e.kind == 2) typeface = Typeface.DEFAULT_BOLD
            }
        }
    }

    private fun size(n: Long) = if (n < 1024 * 1024) "${n / 1024}K" else String.format("%.1fM", n / 1048576.0)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        exts = (intent.getStringArrayExtra("exts") ?: emptyArray()).map { it.lowercase() }.toSet()
        multi = intent.getBooleanExtra("multi", false)
        prefs.getString("dir", null)?.let { if (File(it).isDirectory) dir = File(it) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(WHITE)
            setPadding(dp(16), dp(20), dp(16), dp(8))
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = "选择文件"; textSize = 24f; typeface = Typeface.DEFAULT_BOLD; setTextColor(BLACK)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        confirm = btn("导入所选(0)") { finishWith(selected.toList()) }
        confirm.visibility = if (multi) View.VISIBLE else View.GONE
        head.addView(confirm, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        head.addView(btn("取消") { finish() })
        root.addView(head)

        pathView = TextView(this).apply {
            textSize = 14f; setTextColor(0xFF444444.toInt()); setPadding(0, dp(8), 0, dp(4))
        }
        root.addView(pathView)

        val rootsRow = LinearLayout(this)
        var sd = 0
        val ext = Environment.getExternalStorageDirectory()
        rootsRow.addView(btn("内部存储") { dir = ext; load() }, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        File("/storage").listFiles()?.sortedBy { it.name }?.forEach { f ->
            if (f.isDirectory && f.name != "emulated" && f.name != "self" && f.canRead()) {
                sd++
                rootsRow.addView(btn(if (sd == 1) "SD卡" else "SD卡$sd") { dir = f; load() },
                    LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
            }
        }
        root.addView(HorizontalScrollView(this).apply { addView(rootsRow) })

        root.addView(View(this).apply { setBackgroundColor(BLACK) },
            LinearLayout.LayoutParams(MATCH, 3).apply { topMargin = dp(8) })

        hint = TextView(this).apply {
            textSize = 16f; setTextColor(0xFF444444.toInt()); setPadding(0, dp(12), 0, dp(8)); visibility = View.GONE
        }
        root.addView(hint)

        listView = ListView(this).apply {
            divider = ColorDrawable(0xFF999999.toInt()); dividerHeight = 2
            selector = ColorDrawable(Color.TRANSPARENT)
            this.adapter = this@PickFileActivity.adapter
            setOnItemClickListener { _, _, i, _ -> onPick(items[i]) }
        }
        root.addView(listView, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 1)
        } else load()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        load()   // 不管是否授权都先试着读，读不出来会给出提示
    }

    private fun btn(label: String, f: () -> Unit) = TextView(this).apply {
        text = label; textSize = 17f; setTextColor(BLACK); background = box(WHITE, BLACK)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        setOnClickListener { f() }
    }

    private fun load() {
        prefs.edit().putString("dir", dir.path).apply()
        pathView.text = dir.path
        val list = ArrayList<Entry>()
        dir.parentFile?.let { list.add(Entry(it, "", 0)) }
        val files = dir.listFiles()
        if (files == null) {
            hint.text = "无法读取这个文件夹。请到 系统设置 → 应用 → 劝读 → 权限，打开「存储」权限后重试。"
            hint.visibility = View.VISIBLE
        } else {
            val dirs = files.filter { it.isDirectory && !it.name.startsWith(".") }.sortedBy { it.name.lowercase() }
            val fs = files.filter { it.isFile && !it.name.startsWith(".") && exts.contains(it.extension.lowercase()) }
                .sortedBy { it.name.lowercase() }
            dirs.forEach { list.add(Entry(it, it.name, 1)) }
            fs.forEach { list.add(Entry(it, it.name, 2)) }
            if (dirs.isEmpty() && fs.isEmpty()) {
                hint.text = "这里没有可选的文件（只显示 ${exts.joinToString(" / ")}）"
                hint.visibility = View.VISIBLE
            } else hint.visibility = View.GONE
        }
        items = list
        adapter.notifyDataSetChanged()
        listView.setSelection(0)
    }

    private fun onPick(e: Entry) {
        when (e.kind) {
            0, 1 -> { dir = e.file; load() }
            else -> if (multi) {
                if (!selected.add(e.file.path)) selected.remove(e.file.path)
                confirm.text = "导入所选(${selected.size})"
                adapter.notifyDataSetChanged()
            } else finishWith(listOf(e.file.path))
        }
    }

    private fun finishWith(paths: List<String>) {
        if (paths.isEmpty()) { toast("还没有选文件"); return }
        setResult(RESULT_OK, Intent().putStringArrayListExtra("paths", ArrayList(paths)))
        finish()
    }
}
