package com.example.einkreader

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.OpenableColumns
import android.view.ViewGroup
import android.widget.Toast

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
const val BLACK = Color.BLACK
const val WHITE = Color.WHITE

fun Context.dp(n: Int): Int = (n * resources.displayMetrics.density + 0.5f).toInt()

fun box(fill: Int, stroke: Int, w: Int = 2): GradientDrawable =
    GradientDrawable().apply { setColor(fill); setStroke(w, stroke) }

fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

fun Context.displayName(uri: Uri): String? = try {
    contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) {
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0) c.getString(i) else null
        } else null
    }
} catch (e: Exception) { null }
