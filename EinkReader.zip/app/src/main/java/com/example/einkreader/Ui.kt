package com.example.einkreader

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.OpenableColumns
import android.view.ViewGroup
import android.widget.Toast

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
const val BLACK = Color.BLACK
const val WHITE = Color.WHITE

fun Context.dp(n: Int): Int = (n * resources.displayMetrics.density + 0.5f).toInt()

fun box(fill: Int, stroke: Int, w: Int = 2): GradientDrawable =
    GradientDrawable().apply { setColor(fill); setStroke(w, stroke) }

fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

fun Context.displayName(uri: Uri): String? = try {
    contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) {
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0) c.getString(i) else null
        } else null
    }
} catch (e: Exception) { null }

/** 按保存的设置锁定横屏 / 竖屏（这台机器没有重力感应，靠按钮切换） */
fun Activity.applySavedOrientation(s: Settings) {
    requestedOrientation = when (s.orient) {
        1 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        2 -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        else -> requestedOrientation
    }
}

fun Activity.toggleOrientation(s: Settings) {
    val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    s.orient = if (land) 1 else 2
    applySavedOrientation(s)
}

fun humanSize(n: Long): String =
    if (n < 1024 * 1024) "${n / 1024}K" else String.format("%.1fM", n / 1048576.0)
