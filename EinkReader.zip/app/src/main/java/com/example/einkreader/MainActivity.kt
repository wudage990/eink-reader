package com.example.einkreader

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private lateinit var reader: ReaderView
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private val bookCache get() = File(filesDir, "book.txt")
    private val REQ_BOOK = 1
    private val REQ_FONT = 2

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        reader = ReaderView(this)
        setContentView(reader)
        hideBars()
        reader.onMenu = { showMenu() }
        reader.textSizePx = prefs.getFloat("size", 44f)
        reader.lineExtraPx = prefs.getFloat("extra", 24f)
        reader.underline = prefs.getBoolean("underline", true)
        reader.bgColor = prefs.getInt("bg", Color.WHITE)
        loadFont(prefs.getString("font", null))
        if (bookCache.exists()) {
            reader.text = bookCache.readText()
            reader.start = prefs.getInt("pos", 0)
        } else showMenu()
    }

    private fun hideBars() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    override fun onPause() { super.onPause(); prefs.edit().putInt("pos", reader.start).apply() }

    override fun onKeyDown(k: Int, e: KeyEvent): Boolean = when (k) {
        KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> { reader.next(); true }
        KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_PAGE_UP -> { reader.prev(); true }
        else -> super.onKeyDown(k, e)
    }

    private fun showMenu() {
        val items = arrayOf("打开书籍 (TXT/EPUB)", "选择字体 (TTF/OTF)", "恢复默认字体",
            "字号 +", "字号 -", "行距 +", "行距 -",
            if (reader.underline) "关闭下划线" else "开启下划线",
            "背景：白 / 米黄", "每 5/10/20 页全刷")
        AlertDialog.Builder(this).setItems(items) { _, i ->
            when (i) {
                0 -> pick(REQ_BOOK)
                1 -> pick(REQ_FONT)
                2 -> { prefs.edit().remove("font").apply(); loadFont(null); reader.relayout() }
                3 -> change("size", reader.textSizePx + 4f) { reader.textSizePx = it }
                4 -> change("size", reader.textSizePx - 4f) { reader.textSizePx = it.coerceAtLeast(20f) }
                5 -> change("extra", reader.lineExtraPx + 4f) { reader.lineExtraPx = it }
                6 -> change("extra", reader.lineExtraPx - 4f) { reader.lineExtraPx = it.coerceAtLeast(10f) }
                7 -> { reader.underline = !reader.underline
                       prefs.edit().putBoolean("underline", reader.underline).apply(); reader.invalidate() }
                8 -> { reader.bgColor = if (reader.bgColor == Color.WHITE) 0xFFF4ECD8.toInt() else Color.WHITE
                       prefs.edit().putInt("bg", reader.bgColor).apply(); reader.invalidate() }
                9 -> { reader.fullRefreshEvery = when (reader.fullRefreshEvery) { 5 -> 10; 10 -> 20; else -> 5 }
                       Toast.makeText(this, "每 ${reader.fullRefreshEvery} 页全刷", Toast.LENGTH_SHORT).show() }
            }
        }.show()
    }

    private fun change(key: String, v: Float, apply: (Float) -> Unit) {
        apply(v); prefs.edit().putFloat(key, v).apply(); reader.relayout()
    }

    private fun pick(req: Int) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }, req)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        val uri: Uri = data?.data ?: return
        if (res != RESULT_OK) return
        if (req == REQ_FONT) {
            val f = File(filesDir, "user_font")
            contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            if (loadFont(f.path)) { prefs.edit().putString("font", f.path).apply(); reader.relayout() }
            else Toast.makeText(this, "字体文件无法加载", Toast.LENGTH_SHORT).show()
        } else if (req == REQ_BOOK) {
            Toast.makeText(this, "正在解析…", Toast.LENGTH_SHORT).show()
            Thread {
                try {
                    val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    val t = BookLoader.load(bytes)
                    bookCache.writeText(t)
                    runOnUiThread { reader.text = t; prefs.edit().putInt("pos", 0).apply() }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this, "打开失败：${e.message}", Toast.LENGTH_LONG).show() }
                }
            }.start()
        }
    }

    private fun loadFont(path: String?): Boolean {
        if (path == null) { reader.typeface = Typeface.SERIF; return true }
        return try { reader.typeface = Typeface.createFromFile(path); true }
        catch (e: Exception) { reader.typeface = Typeface.SERIF; false }
    }
}
