package com.example.einkreader

import android.content.Context
import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

class ReaderView(ctx: Context) : View(ctx) {

    var text = ""
        private set
    var chapters: List<Chapter> = emptyList()
        private set
    var start = 0
        private set

    var onMenu: (() -> Unit)? = null
    var onPage: ((Int) -> Unit)? = null
    var fullRefreshEvery = 10

    var typeface: Typeface = Typeface.SERIF
    var textSizePx = 44f
    var weight = 0                 // 0..10 字体粗细（描边加粗）
    var lineExtraPx = 24f
    var underlineStyle = 1         // 0 无 1 实线 2 虚线
    var bgMode = 0                 // 0 白 1 米黄 2 图片
    var bgAlpha = 40               // 背景图浓度 %
    var marginH = 48
    private val marginV = 64

    private var bg: Bitmap? = null
    private val bgPaint = Paint().apply {
        isFilterBitmap = true
        colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
    }
    private val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val linePaint = Paint().apply { color = Color.BLACK; strokeWidth = 2f }
    private val infoPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF333333.toInt(); textSize = 26f }
    private val history = ArrayList<Int>()
    private var layout: StaticLayout? = null
    private var lines = 0
    private var nextStart = 0
    private var pageCount = 0
    private var flashBlack = false

    fun setBook(t: String, chs: List<Chapter>, pos: Int) {
        text = t; chapters = chs
        start = pos.coerceIn(0, max(0, t.length - 1))
        history.clear(); layout = null; invalidate()
    }

    fun relayout() { layout = null; history.clear(); invalidate() }

    fun jumpTo(offset: Int) {
        start = offset.coerceIn(0, max(0, text.length - 1))
        history.clear(); layout = null
        turned()
    }

    fun loadBgImage(path: String?) {
        bg?.recycle(); bg = null
        if (path != null) {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, o)
            var s = 1
            while (o.outWidth / s > 2000 || o.outHeight / s > 2000) s *= 2
            bg = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
        }
        invalidate()
    }

    fun chapterIndex(): Int {
        var lo = 0
        var hi = chapters.size - 1
        var ans = 0
        while (lo <= hi) {
            val m = (lo + hi) ushr 1
            if (chapters[m].offset <= start) { ans = m; lo = m + 1 } else hi = m - 1
        }
        return ans
    }

    private fun applyPaint() {
        paint.typeface = typeface
        paint.textSize = textSizePx
        if (weight > 0) {
            paint.style = Paint.Style.FILL_AND_STROKE
            paint.strokeWidth = weight * textSizePx * 0.004f
        } else {
            paint.style = Paint.Style.FILL
            paint.strokeWidth = 0f
        }
    }

    private fun build(from: Int, to: Int): StaticLayout {
        applyPaint()
        return StaticLayout(text.substring(from, to), paint, max(10, width - 2 * marginH),
            Layout.Alignment.ALIGN_NORMAL, 1f, lineExtraPx, false)
    }

    private fun fitLines(l: StaticLayout): Int {
        val h = height - 2 * marginV
        var n = 0
        while (n < l.lineCount && l.getLineBottom(n) <= h) n++
        return max(n, 1)
    }

    private fun ensureLayout() {
        if (layout != null || width == 0 || text.isEmpty()) return
        start = start.coerceIn(0, max(0, text.length - 1))
        val l = build(start, min(text.length, start + 6000))
        lines = fitLines(l)
        nextStart = start + l.getLineEnd(lines - 1)
        layout = l
    }

    private fun drawBackground(c: Canvas) {
        c.drawColor(if (bgMode == 1) 0xFFF4ECD8.toInt() else Color.WHITE)
        val b = bg
        if (bgMode == 2 && b != null) {
            val bw = b.width.toFloat(); val bh = b.height.toFloat()
            val scale = max(width / bw, height / bh)
            val sw = width / scale; val sh = height / scale
            val src = Rect(((bw - sw) / 2).toInt(), ((bh - sh) / 2).toInt(),
                ((bw + sw) / 2).toInt(), ((bh + sh) / 2).toInt())
            bgPaint.alpha = bgAlpha * 255 / 100
            c.drawBitmap(b, src, Rect(0, 0, width, height), bgPaint)
        }
    }

    override fun onDraw(c: Canvas) {
        if (flashBlack) { c.drawColor(Color.BLACK); return }
        drawBackground(c)
        ensureLayout()
        val l = layout ?: return
        val availW = width - 2 * marginH

        val title = chapters.getOrNull(chapterIndex())?.title
        if (!title.isNullOrEmpty()) {
            val t = TextUtils.ellipsize(title, infoPaint, availW.toFloat(), TextUtils.TruncateAt.END)
            c.drawText(t, 0, t.length, marginH.toFloat(), 40f, infoPaint)
        }

        c.save()
        c.translate(marginH.toFloat(), marginV.toFloat())
        c.clipRect(0, 0, availW, l.getLineBottom(lines - 1))
        l.draw(c)
        if (underlineStyle != 0) {
            val w = availW.toFloat()
            for (i in 0 until lines) {
                val y = l.getLineBaseline(i) + paint.descent() * 0.6f
                if (underlineStyle == 1) {
                    c.drawLine(0f, y, w, y, linePaint)
                } else {
                    var x = 0f
                    while (x < w) {
                        c.drawLine(x, y, min(x + 12f, w), y, linePaint)
                        x += 20f
                    }
                }
            }
        }
        c.restore()

        val pct = if (text.isEmpty()) 0 else (start * 100L / text.length).toInt()
        c.drawText("$pct%", marginH.toFloat(), height - 20f, infoPaint)
    }

    fun next() {
        ensureLayout()
        if (nextStart >= text.length) return
        history.add(start); start = nextStart; layout = null
        turned()
    }

    fun prev() {
        if (start <= 0) return
        if (history.isNotEmpty()) {
            start = history.removeAt(history.size - 1)
        } else {
            val segStart = max(0, start - 3000)
            val l = build(segStart, start)
            val n = fitLines(l)
            start = segStart + l.getLineStart(max(0, l.lineCount - n))
        }
        layout = null
        turned()
    }

    private fun turned() {
        pageCount++
        onPage?.invoke(start)
        if (fullRefreshEvery > 0 && pageCount % fullRefreshEvery == 0) {
            flashBlack = true; invalidate()
            postDelayed({ flashBlack = false; invalidate() }, 150)
        } else invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            val x = e.x / width
            when {
                x < 0.33f -> prev()
                x > 0.67f -> next()
                else -> onMenu?.invoke()
            }
        }
        return true
    }
}
