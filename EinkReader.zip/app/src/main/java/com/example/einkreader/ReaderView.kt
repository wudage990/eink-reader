package com.example.einkreader

import android.content.Context
import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

class ReaderView(ctx: Context) : View(ctx) {

    var text = ""
        set(v) { field = v; start = 0; history.clear(); layout = null; invalidate() }
    var start = 0                       // 当前页起点（字符偏移）
    var onMenu: (() -> Unit)? = null
    var fullRefreshEvery = 10           // 每 N 页全刷一次，0 = 不全刷

    // 可调样式
    var typeface: Typeface = Typeface.SERIF
    var textSizePx = 44f
    var lineExtraPx = 24f               // 额外行距（下划线要落在这里面）
    var underline = true
    var underlineWidth = 2f
    var bgColor = Color.WHITE
    var marginH = 48
    var marginV = 56

    private val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val linePaint = Paint().apply { color = Color.BLACK; isAntiAlias = false }
    private val infoPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = 26f }
    private val history = ArrayList<Int>()
    private var layout: StaticLayout? = null
    private var lines = 0
    private var nextStart = 0
    private var pageCount = 0
    private var flashBlack = false

    fun relayout() { layout = null; history.clear(); invalidate() }

    private fun applyPaint() {
        paint.typeface = typeface
        paint.textSize = textSizePx
    }

    private fun build(from: Int, to: Int): StaticLayout {
        applyPaint()
        return StaticLayout(text.substring(from, to), paint, width - 2 * marginH,
            Layout.Alignment.ALIGN_NORMAL, 1f, lineExtraPx, false)
    }

    private fun fitLines(l: StaticLayout): Int {
        val h = height - 2 * marginV
        var n = 0
        while (n < l.lineCount && l.getLineBottom(n) <= h) n++
        return max(n, 1)
    }

    private fun ensureLayout() {
        if (layout != null || width == 0 || text.isEmpty()) return
        start = start.coerceIn(0, max(0, text.length - 1))
        val l = build(start, min(text.length, start + 6000))
        lines = fitLines(l)
        nextStart = start + l.getLineEnd(lines - 1)
        layout = l
    }

    override fun onDraw(c: Canvas) {
        if (flashBlack) { c.drawColor(Color.BLACK); return }
        c.drawColor(bgColor)
        ensureLayout()
        val l = layout ?: return
        c.save()
        c.translate(marginH.toFloat(), marginV.toFloat())
        c.clipRect(0, 0, width - 2 * marginH, l.getLineBottom(lines - 1))
        l.draw(c)
        if (underline) {
            linePaint.strokeWidth = underlineWidth
            for (i in 0 until lines) {
                // 用基线定位，换字体/字号后依然对齐
                val y = l.getLineBaseline(i) + paint.descent() * 0.6f
                c.drawLine(0f, y, (width - 2 * marginH).toFloat(), y, linePaint)
            }
        }
        c.restore()
        val pct = if (text.isEmpty()) 0 else start * 100 / text.length
        c.drawText("$pct%", marginH.toFloat(), height - 14f, infoPaint)
    }

    fun next() {
        ensureLayout()
        if (nextStart >= text.length) return
        history.add(start); start = nextStart; layout = null
        turned()
    }

    fun prev() {
        if (start <= 0) return
        if (history.isNotEmpty()) {
            start = history.removeAt(history.size - 1)
        } else {                         // 恢复进度后没有历史，向前反推一页
            val segStart = max(0, start - 3000)
            val l = build(segStart, start)
            val n = fitLines(l)
            start = segStart + l.getLineStart(max(0, l.lineCount - n))
        }
        layout = null
        turned()
    }

    private fun turned() {
        pageCount++
        if (fullRefreshEvery > 0 && pageCount % fullRefreshEvery == 0) {
            flashBlack = true; invalidate()
            postDelayed({ flashBlack = false; invalidate() }, 150)
        } else invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            val x = e.x / width
            when { x < 0.33f -> prev(); x > 0.67f -> next(); else -> onMenu?.invoke() }
        }
        return true
    }
}
