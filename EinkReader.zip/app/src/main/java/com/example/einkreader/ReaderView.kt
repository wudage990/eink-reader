package com.example.einkreader

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class ReaderView(ctx: Context) : View(ctx) {

    var text = ""
        private set
    var chapters: List<Chapter> = emptyList()
        private set
    var start = 0
        private set

    var onMenu: (() -> Unit)? = null
    var onPage: ((Int) -> Unit)? = null
    var onTapIntercept: (() -> Boolean)? = null
    var fullRefreshEvery = 10
    var flipMode = 0               // 0 无动画 1 卷页

    var typeface: Typeface = Typeface.SERIF
    var textSizePx = 44f
    var weight = 0                 // 0..10 字体粗细（描边加粗）
    var lineExtraPx = 24f
    var underlineStyle = 1         // 0 无 1 实线 2 虚线
    var bgMode = 0                 // 0 白 1 米黄 2 护眼绿 3 图片
    var bgAlpha = 40               // 背景图浓度 %
    var marginH = 48
    private val marginV = 64

    private class Page(val start: Int, val layout: StaticLayout, val lines: Int, val next: Int)

    private var page: Page? = null
    private val history = ArrayList<Int>()
    private var pageCount = 0
    private var flashBlack = false

    // 背景图
    private var bg: Bitmap? = null
    private val bgPaint = Paint().apply {
        isFilterBitmap = true
        colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
    }
    private val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val linePaint = Paint().apply { color = Color.BLACK; strokeWidth = 2f }
    private val infoPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF333333.toInt(); textSize = 26f }

    // 卷页动画
    private var animating = false
    private var animT = 0f
    private var animator: ValueAnimator? = null
    private var curlTop: Bitmap? = null
    private var curlUnder: Bitmap? = null
    private val paperPaint = Paint().apply { color = 0xFFEFEFEF.toInt() }
    private val ghostPaint = Paint().apply { isFilterBitmap = true }
    private val shadePaint = Paint().apply { color = Color.BLACK }
    private val edgePaint = Paint().apply { color = 0xFF777777.toInt() }
    private val shadowPaint = Paint()

    // ---------------- 对外接口 ----------------
    fun setBook(t: String, chs: List<Chapter>, pos: Int) {
        cancelCurl()
        text = t; chapters = chs
        start = pos.coerceIn(0, max(0, t.length - 1))
        history.clear(); page = null; invalidate()
    }

    fun relayout() { cancelCurl(); page = null; history.clear(); invalidate() }

    fun jumpTo(offset: Int) {
        cancelCurl()
        start = offset.coerceIn(0, max(0, text.length - 1))
        history.clear(); page = null
        turned()
    }

    fun loadBgImage(path: String?) {
        bg?.recycle(); bg = null
        if (path != null) {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, o)
            var s = 1
            while (o.outWidth / s > 2000 || o.outHeight / s > 2000) s *= 2
            bg = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
        }
        invalidate()
    }

    fun chapterIndex(): Int = chapterIndexAt(start)

    private fun chapterIndexAt(offset: Int): Int {
        var lo = 0
        var hi = chapters.size - 1
        var ans = 0
        while (lo <= hi) {
            val m = (lo + hi) ushr 1
            if (chapters[m].offset <= offset) { ans = m; lo = m + 1 } else hi = m - 1
        }
        return ans
    }

    // ---------------- 排版 ----------------
    private fun applyPaint() {
        paint.typeface = typeface
        paint.textSize = textSizePx
        if (weight > 0) {
            paint.style = Paint.Style.FILL_AND_STROKE
            paint.strokeWidth = weight * textSizePx * 0.004f
        } else {
            paint.style = Paint.Style.FILL
            paint.strokeWidth = 0f
        }
    }

    private fun build(from: Int, to: Int): StaticLayout {
        applyPaint()
        return StaticLayout(text.substring(from, to), paint, max(10, width - 2 * marginH),
            Layout.Alignment.ALIGN_NORMAL, 1f, lineExtraPx, false)
    }

    private fun fitLines(l: StaticLayout): Int {
        val h = height - 2 * marginV
        var n = 0
        while (n < l.lineCount && l.getLineBottom(n) <= h) n++
        return max(n, 1)
    }

    /** 估算一页大概要多少字，只排这么多，横竖屏切换和翻页都更快 */
    private fun estimateChars(): Int {
        val availW = max(100, width - 2 * marginH).toFloat()
        val h = max(100, height - 2 * marginV).toFloat()
        val perLine = availW / max(8f, textSizePx * 0.45f)
        val lineH = textSizePx * 1.2f + lineExtraPx
        return (perLine * (h / lineH) * 1.3f).toInt() + 200
    }

    private fun layoutAt(from: Int): Page? {
        if (width == 0 || height == 0 || text.isEmpty() || from >= text.length) return null
        var chunk = estimateChars()
        while (true) {
            val to = min(text.length, from + chunk)
            val l = build(from, to)
            val n = fitLines(l)
            if (n < l.lineCount || to >= text.length)
                return Page(from, l, n, from + l.getLineEnd(n - 1))
            chunk *= 2
        }
    }

    private fun prevStartOf(from: Int): Int {
        if (from <= 0) return 0
        var chunk = estimateChars()
        while (true) {
            val segStart = max(0, from - chunk)
            val l = build(segStart, from)
            val n = fitLines(l)
            if (segStart == 0 || l.lineCount > n)
                return segStart + l.getLineStart(max(0, l.lineCount - n))
            chunk *= 2
        }
    }

    private fun ensurePage(): Page? {
        if (page == null) {
            start = start.coerceIn(0, max(0, text.length - 1))
            page = layoutAt(start)
        }
        return page
    }

    // ---------------- 绘制 ----------------
    private fun drawBackground(c: Canvas) {
        c.drawColor(when (bgMode) {
            1 -> 0xFFF4ECD8.toInt()
            2 -> 0xFFC7EDCC.toInt()
            else -> Color.WHITE
        })
        val b = bg
        if (bgMode == 3 && b != null) {
            val bw = b.width.toFloat(); val bh = b.height.toFloat()
            val scale = max(width / bw, height / bh)
            val sw = width / scale; val sh = height / scale
            val src = Rect(((bw - sw) / 2).toInt(), ((bh - sh) / 2).toInt(),
                ((bw + sw) / 2).toInt(), ((bh + sh) / 2).toInt())
            bgPaint.alpha = bgAlpha * 255 / 100
            c.drawBitmap(b, src, Rect(0, 0, width, height), bgPaint)
        }
    }

    private fun drawPage(c: Canvas, p: Page) {
        drawBackground(c)
        val l = p.layout
        val availW = width - 2 * marginH

        val title = chapters.getOrNull(chapterIndexAt(p.start))?.title
        if (!title.isNullOrEmpty()) {
            val t = TextUtils.ellipsize(title, infoPaint, availW.toFloat(), TextUtils.TruncateAt.END)
            c.drawText(t, 0, t.length, marginH.toFloat(), 40f, infoPaint)
        }

        c.save()
        c.translate(marginH.toFloat(), marginV.toFloat())
        c.clipRect(0, 0, availW, l.getLineBottom(p.lines - 1))
        l.draw(c)
        if (underlineStyle != 0) {
            val w = availW.toFloat()
            for (i in 0 until p.lines) {
                val y = l.getLineBaseline(i) + paint.descent() * 0.6f
                if (underlineStyle == 1) {
                    c.drawLine(0f, y, w, y, linePaint)
                } else {
                    var x = 0f
                    while (x < w) {
                        c.drawLine(x, y, min(x + 12f, w), y, linePaint)
                        x += 20f
                    }
                }
            }
        }
        c.restore()

        val pct = if (text.isEmpty()) 0 else (p.start * 100L / text.length).toInt()
        c.drawText("$pct%", marginH.toFloat(), height - 20f, infoPaint)
    }

    override fun onDraw(c: Canvas) {
        if (flashBlack) { c.drawColor(Color.BLACK); return }
        if (animating) { drawCurl(c); return }
        val p = ensurePage()
        if (p == null) drawBackground(c) else drawPage(c, p)
    }

    // ---------------- 翻页 ----------------
    fun next() {
        if (animating) return
        val cur = ensurePage() ?: return
        if (cur.next >= text.length) return
        val nxt = layoutAt(cur.next) ?: return
        val commit = { history.add(start); start = nxt.start; page = nxt; turned() }
        if (flipMode == 1) startCurl(cur, nxt, true, commit) else commit()
    }

    fun prev() {
        if (animating || start <= 0) return
        val cur = ensurePage() ?: return
        val ps = if (history.isNotEmpty()) history[history.size - 1] else prevStartOf(start)
        val prv = layoutAt(ps) ?: return
        val commit = {
            if (history.isNotEmpty()) history.removeAt(history.size - 1)
            start = prv.start; page = prv; turned()
        }
        if (flipMode == 1) startCurl(prv, cur, false, commit) else commit()
    }

    private fun turned() {
        pageCount++
        onPage?.invoke(start)
        if (fullRefreshEvery > 0 && pageCount % fullRefreshEvery == 0) {
            flashBlack = true; invalidate()
            postDelayed({ flashBlack = false; invalidate() }, 150)
        } else invalidate()
    }

    // ---------------- 卷页动画 ----------------
    private fun snapshot(p: Page): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)
        drawPage(Canvas(bmp), p)
        return bmp
    }

    private fun startCurl(top: Page, under: Page, forward: Boolean, done: () -> Unit) {
        val bt = try { snapshot(top) } catch (e: Throwable) { null }
        val bu = try { snapshot(under) } catch (e: Throwable) { null }
        if (bt == null || bu == null) {
            bt?.recycle(); bu?.recycle(); done(); return
        }
        curlTop = bt; curlUnder = bu
        animating = true
        animT = if (forward) 0f else 1f
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 420
        a.addUpdateListener { v ->
            val x = v.animatedValue as Float
            animT = if (forward) x else 1f - x
            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: Animator) {
                animator = null; animating = false
                curlTop?.recycle(); curlTop = null
                curlUnder?.recycle(); curlUnder = null
                done()
            }
        })
        animator = a
        a.start()
    }

    private fun cancelCurl() {
        animator?.let { it.removeAllListeners(); it.cancel() }
        animator = null; animating = false
        curlTop?.recycle(); curlTop = null
        curlUnder?.recycle(); curlUnder = null
    }

    /**
     * 卷页：折线 f 从右向左移动，折起的纸背绕一个圆柱卷过去。
     * 下层是另一页，卷起处有渐变阴影，看起来像一道波纹。
     */
    private fun drawCurl(c: Canvas) {
        val top = curlTop ?: return
        val under = curlUnder ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        val rMax = min(w, h) * 0.09f
        val f = w - animT * (w + rMax * 1.2f)
        val r = max(1f, min(rMax, (w - f) / PI.toFloat()))
        val pr = PI.toFloat() * r

        // 1. 下层页 + 卷起处投在它上面的阴影
        c.drawBitmap(under, 0f, 0f, null)
        val rx = f + r
        if (rx < w) {
            shadowPaint.shader = LinearGradient(rx, 0f, rx + r * 1.6f, 0f,
                0x66000000, 0x00000000, Shader.TileMode.CLAMP)
            c.drawRect(max(0f, rx), 0f, w, h, shadowPaint)
        }

        // 2. 还没翻起的上层页（折线左边）
        if (f > 0f) {
            c.save()
            c.clipRect(0f, 0f, min(f, w), h)
            c.drawBitmap(top, 0f, 0f, null)
            c.restore()

            // 3. 翻到左侧的纸背（镜像、淡淡透出文字）
            val xl = 2f * f + pr - w
            if (xl < f) {
                if (xl > 0f) {
                    shadowPaint.shader = LinearGradient(xl, 0f, xl - r * 1.2f, 0f,
                        0x55000000, 0x00000000, Shader.TileMode.CLAMP)
                    c.drawRect(max(0f, xl - r * 1.2f), 0f, xl, h, shadowPaint)
                }
                c.save()
                c.clipRect(max(0f, xl), 0f, min(f, w), h)
                c.translate(2f * f + pr, 0f)
                c.scale(-1f, 1f)
                c.drawRect(0f, 0f, w, h, paperPaint)
                ghostPaint.alpha = 50
                c.drawBitmap(top, 0f, 0f, ghostPaint)
                c.restore()
                if (xl > 0f) c.drawRect(xl, 0f, xl + 2f, h, edgePaint)
            }
        }

        // 4. 卷起的圆柱面：一条条竖条，按圆弧压缩并加明暗
        val half = PI.toFloat() * r / 2f
        val n = max(6, (half / 2f).toInt())
        for (i in 0 until n) {
            val da = half + i * half / n
            val db = half + (i + 1) * half / n
            val sa = f + da
            val sb = f + db
            if (sb <= 0f || sa >= w) continue
            val xa = f + r * sin(da / r)
            val xb = f + r * sin(db / r)
            val left = min(xa, xb)
            val right = max(xa, xb) + 1f
            if (right <= 0f || left >= w) continue
            val dst = RectF(left, 0f, right, h)
            c.drawRect(dst, paperPaint)
            val sl = max(0f, sa).toInt()
            val sr = max(sl + 1, min(w, sb).toInt())
            ghostPaint.alpha = 50
            c.drawBitmap(top, Rect(sl, 0, sr, height), dst, ghostPaint)
            val u = (i + 0.5f) / n
            val dark = 0.55f * (1f - u) * (1f - u)
            shadePaint.alpha = (dark * 255).toInt()
            c.drawRect(dst, shadePaint)
        }
    }

    // ---------------- 尺寸 / 触摸 ----------------
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        cancelCurl()
        page = null
        history.clear()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            if (animating) return true
            if (onTapIntercept?.invoke() == true) return true
            val x = e.x / width
            when {
                x < 0.33f -> prev()
                x > 0.67f -> next()
                else -> onMenu?.invoke()
            }
        }
        return true
    }
}
