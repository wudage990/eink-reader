package com.example.einkreader

import android.content.Context
import android.graphics.Typeface
import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.random.Random

class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("cfg2", Context.MODE_PRIVATE)

    var fontKey: String
        get() = p.getString("font", "serif") ?: "serif"
        set(v) { p.edit().putString("font", v).apply() }
    var textSize: Float
        get() = p.getFloat("size", 44f)
        set(v) { p.edit().putFloat("size", v).apply() }
    var weight: Int
        get() = p.getInt("weight", 0)
        set(v) { p.edit().putInt("weight", v).apply() }
    var letterSpace: Int        // 字间距，1/100 字宽
        get() = p.getInt("letter", 0)
        set(v) { p.edit().putInt("letter", v).apply() }
    var lineExtra: Float
        get() = p.getFloat("extra", 24f)
        set(v) { p.edit().putFloat("extra", v).apply() }
    var margin: Int
        get() = p.getInt("margin", 48)
        set(v) { p.edit().putInt("margin", v).apply() }
    var smooth: Boolean         // 字体平滑
        get() = p.getBoolean("smooth", true)
        set(v) { p.edit().putBoolean("smooth", v).apply() }
    var underline: Int          // 0 无 1 实线 2 虚线 3 点线 4 点划线
        get() = p.getInt("underline", 1)
        set(v) { p.edit().putInt("underline", v).apply() }
    var bgMode: Int             // 0 白 1 米黄 2 护眼绿 3 图片
        get() = p.getInt("bgMode2", 0)
        set(v) { p.edit().putInt("bgMode2", v).apply() }
    var bgAlpha: Int
        get() = p.getInt("bgAlpha", 40)
        set(v) { p.edit().putInt("bgAlpha", v).apply() }
    var flip: Int               // 0 无动画 1 卷页
        get() = p.getInt("flip", 0)
        set(v) { p.edit().putInt("flip", v).apply() }
    var refreshEvery: Int
        get() = p.getInt("refresh", 10)
        set(v) { p.edit().putInt("refresh", v).apply() }
    var autoSec: Int            // 自动翻页间隔（秒）
        get() = p.getInt("autoSec", 20)
        set(v) { p.edit().putInt("autoSec", v).apply() }
    var orient: Int             // 0 跟随系统 1 竖屏 2 横屏
        get() = p.getInt("orient", 0)
        set(v) { p.edit().putInt("orient", v).apply() }
    var shelfMode: Int          // 0 列表 1 图标
        get() = p.getInt("shelfMode", 0)
        set(v) { p.edit().putInt("shelfMode", v).apply() }
}

object Fonts {
    private val cache = HashMap<String, Typeface>()
    private val EXTS = setOf("ttf", "otf", "ttc")

    /** 字体文件夹：把字体文件放进去，「字体」功能里就会列出来 */
    fun dir(): File = File(Environment.getExternalStorageDirectory(), "劝读/字体")

    /** 返回 null 表示读不到这个文件夹（没有权限，或文件夹还没创建） */
    fun scan(): List<File>? {
        val root = dir()
        if (!root.exists()) root.mkdirs()
        if (root.listFiles() == null) return null
        val out = ArrayList<File>()
        fun walk(d: File, depth: Int) {
            val fs = d.listFiles() ?: return
            for (f in fs.sortedBy { it.name.lowercase() }) {
                if (f.isDirectory) {
                    if (depth < 2) walk(f, depth + 1)
                } else if (f.isFile && EXTS.contains(f.extension.lowercase())) out.add(f)
            }
        }
        walk(root, 0)
        return out
    }

    fun get(ctx: Context, key: String): Typeface {
        cache[key]?.let { return it }
        val tf = try {
            when {
                key == "sans" -> Typeface.SANS_SERIF
                key == "mono" -> Typeface.MONOSPACE
                key.startsWith("path:") -> Typeface.createFromFile(File(key.removePrefix("path:")))
                key.startsWith("file:") -> Typeface.createFromFile(File(File(ctx.filesDir, "fonts"), key.removePrefix("file:")))
                else -> Typeface.SERIF
            }
        } catch (e: Exception) { return Typeface.SERIF }
        cache[key] = tf
        return tf
    }
}

class Book(val id: String, val title: String, val len: Int, val pos: Int, val time: Long,
           val fmt: String, val folder: String)

class Folder(val id: String, val name: String)

class Shelf(ctx: Context) {
    private val p = ctx.getSharedPreferences("shelf", Context.MODE_PRIVATE)
    private val dir = File(ctx.filesDir, "books").also { it.mkdirs() }

    companion object { private val LOCK = Any() }

    fun textFile(id: String) = File(dir, "$id.txt")
    private fun chapFile(id: String) = File(dir, "$id.idx")
    fun newId(): String = System.currentTimeMillis().toString(36) + Random.nextInt(46656).toString(36)

    fun list(): List<Book> = synchronized(LOCK) {
        val arr = JSONArray(p.getString("books", "[]"))
        val out = ArrayList<Book>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.getString("id")
            out.add(Book(id, o.getString("title"), o.getInt("len"),
                p.getInt("pos_$id", 0), p.getLong("t_$id", o.optLong("added", 0)),
                o.optString("fmt", ""), o.optString("folder", "")))
        }
        out.sortedByDescending { it.time }
    }

    /** 文字已经由 BookLoader 写进 textFile(id)，这里登记到书架 */
    fun register(id: String, title: String, len: Int, fmt: String, folder: String, chapters: List<Chapter>) {
        chapFile(id).writeText(chapters.joinToString("\n") {
            "${it.offset}\t${it.title.replace('\t', ' ').replace('\n', ' ')}"
        })
        synchronized(LOCK) {
            val arr = JSONArray(p.getString("books", "[]"))
            val now = System.currentTimeMillis()
            arr.put(JSONObject().put("id", id).put("title", title).put("len", len)
                .put("added", now).put("fmt", fmt).put("folder", folder))
            p.edit().putString("books", arr.toString()).putLong("t_$id", now).apply()
        }
    }

    fun remove(id: String) = synchronized(LOCK) {
        val arr = JSONArray(p.getString("books", "[]"))
        val na = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getString("id") != id) na.put(o)
        }
        p.edit().putString("books", na.toString()).remove("pos_$id").remove("t_$id").apply()
        textFile(id).delete(); chapFile(id).delete()
        Unit
    }

    fun moveBook(bookId: String, folderId: String) = synchronized(LOCK) {
        val arr = JSONArray(p.getString("books", "[]"))
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getString("id") == bookId) o.put("folder", folderId)
        }
        p.edit().putString("books", arr.toString()).apply()
        Unit
    }

    // ---------------- 文件夹（书架里的分类） ----------------
    fun folders(): List<Folder> = synchronized(LOCK) {
        val arr = JSONArray(p.getString("folders", "[]"))
        val out = ArrayList<Folder>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(Folder(o.getString("id"), o.getString("name")))
        }
        out
    }

    fun addFolder(name: String): String = synchronized(LOCK) {
        val id = newId()
        val arr = JSONArray(p.getString("folders", "[]"))
        arr.put(JSONObject().put("id", id).put("name", name))
        p.edit().putString("folders", arr.toString()).apply()
        id
    }

    fun renameFolder(id: String, name: String) = synchronized(LOCK) {
        val arr = JSONArray(p.getString("folders", "[]"))
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getString("id") == id) o.put("name", name)
        }
        p.edit().putString("folders", arr.toString()).apply()
        Unit
    }

    /** 删除文件夹：里面的书回到书架，不会删书 */
    fun removeFolder(id: String) = synchronized(LOCK) {
        val arr = JSONArray(p.getString("folders", "[]"))
        val na = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getString("id") != id) na.put(o)
        }
        val books = JSONArray(p.getString("books", "[]"))
        for (i in 0 until books.length()) {
            val o = books.getJSONObject(i)
            if (o.optString("folder", "") == id) o.put("folder", "")
        }
        p.edit().putString("folders", na.toString()).putString("books", books.toString()).apply()
        Unit
    }

    fun pos(id: String) = p.getInt("pos_$id", 0)

    fun setPos(id: String, pos: Int) {
        p.edit().putInt("pos_$id", pos).putLong("t_$id", System.currentTimeMillis()).apply()
    }

    fun readChapters(id: String): List<Chapter> {
        val f = chapFile(id)
        if (!f.exists()) return emptyList()
        val out = ArrayList<Chapter>()
        for (line in f.readLines()) {
            val i = line.indexOf('\t')
            if (i <= 0) continue
            val off = line.substring(0, i).toIntOrNull() ?: continue
            out.add(Chapter(off, line.substring(i + 1)))
        }
        return out
    }
}
