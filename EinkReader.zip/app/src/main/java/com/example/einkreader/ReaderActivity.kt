package com.example.einkreader

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.io.File
import kotlin.math.max

class ReaderActivity : Activity() {
    private lateinit var reader: ReaderView
    private lateinit var s: Settings
    private lateinit var shelf: Shelf
    private lateinit var bookId: String
    private lateinit var menuBar: LinearLayout
    private lateinit var autoBtn: TextView
    private lateinit var panel: ScrollView          // 设置面板
    private lateinit var fontPanel: ScrollView      // 字体面板
    private lateinit var fontList: LinearLayout
    private lateinit var fontHint: TextView
    private lateinit var bgChips: Chips
    private val fontItems = ArrayList<Pair<String, TextView>>()
    private val REQ_BG = 2
    private val REQ_PERM = 7

    // 自动阅读
    private val handler = Handler(Looper.getMainLooper())
    private var auto = false
    private val tick = object : Runnable {
        override fun run() {
            if (!auto) return
            if (panelOpen() || menuBar.visibility == View.VISIBLE) { handler.postDelayed(this, 1000); return }
            if (reader.atEnd()) { stopAuto(); toast("已读到最后，自动阅读结束"); return }
            reader.next()
            scheduleAuto()
        }
    }

    private fun bgFile() = File(filesDir, "bg_image")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val id = intent.getStringExtra("id")
        if (id == null) { finish(); return }
        bookId = id
        s = Settings(this)
        shelf = Shelf(this)
        val tf = shelf.textFile(bookId)
        if (!tf.exists()) { finish(); return }

        applySavedOrientation(s)
        // 横竖屏切换时直接跳变，不做淡入淡出
        val wlp = window.attributes
        wlp.rotationAnimation = WindowManager.LayoutParams.ROTATION_ANIMATION_JUMPCUT
        window.attributes = wlp

        reader = ReaderView(this)
        buildMenuBar()
        buildSettingsPanel()
        buildFontPanel()
        val root = FrameLayout(this)
        root.addView(reader, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(menuBar, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        root.addView(panel, panelParams())
        root.addView(fontPanel, panelParams())
        setContentView(root)

        if (s.bgMode == 3 && !bgFile().exists()) s.bgMode = 0
        if (bgFile().exists()) reader.loadBgImage(bgFile().path)
        applySettings()
        reader.setBook(tf.readText(), shelf.readChapters(bookId), shelf.pos(bookId))
        reader.onMenu = { onCenterTap() }
        // 点面板以外的空白处：关闭面板
        reader.onTapIntercept = { if (panelOpen()) { closePanels(); true } else false }
        reader.onPage = {
            shelf.setPos(bookId, it)
            if (menuBar.visibility == View.VISIBLE) menuBar.visibility = View.GONE
            if (auto) scheduleAuto()
        }
    }

    override fun onResume() { super.onResume(); hideSystemBars() }

    override fun onPause() {
        super.onPause()
        if (::reader.isInitialized) {
            shelf.setPos(bookId, reader.start)
            stopAuto()
        }
    }

    /** 竖屏：底部 55% 高；横屏：右侧 42% 宽、全高，左边留给正文预览 */
    private fun panelParams(): FrameLayout.LayoutParams {
        val dm = resources.displayMetrics
        return if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
            FrameLayout.LayoutParams((dm.widthPixels * 0.42).toInt(), MATCH, Gravity.END)
        else
            FrameLayout.LayoutParams(MATCH, (dm.heightPixels * 0.55).toInt(), Gravity.BOTTOM)
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (::panel.isInitialized) panel.layoutParams = panelParams()
        if (::fontPanel.isInitialized) fontPanel.layoutParams = panelParams()
        hideSystemBars()
    }

    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    override fun onKeyDown(k: Int, e: KeyEvent): Boolean = when (k) {
        KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> { reader.next(); true }
        KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_PAGE_UP -> { reader.prev(); true }
        else -> super.onKeyDown(k, e)
    }

    override fun onBackPressed() {
        when {
            panelOpen() -> closePanels()
            menuBar.visibility == View.VISIBLE -> menuBar.visibility = View.GONE
            else -> finish()
        }
    }

    private fun panelOpen() = panel.visibility == View.VISIBLE || fontPanel.visibility == View.VISIBLE
    private fun closePanels() { panel.visibility = View.GONE; fontPanel.visibility = View.GONE }

    private fun onCenterTap() {
        if (panelOpen()) closePanels()
        else menuBar.visibility = if (menuBar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    // ---------------- 应用设置到阅读视图 ----------------
    private fun applySettings() {
        reader.typeface = Fonts.get(this, s.fontKey)
        reader.textSizePx = s.textSize
        reader.weight = s.weight
        reader.letterSpacing = s.letterSpace
        reader.smooth = s.smooth
        reader.lineExtraPx = s.lineExtra
        reader.marginH = s.margin
        reader.underlineStyle = s.underline
        reader.bgMode = s.bgMode
        reader.bgAlpha = s.bgAlpha
        reader.fullRefreshEvery = s.refreshEvery
        reader.flipMode = s.flip
        reader.relayout()
    }

    // ---------------- 自动阅读 ----------------
    private fun scheduleAuto() {
        handler.removeCallbacks(tick)
        if (auto) handler.postDelayed(tick, s.autoSec * 1000L)
    }

    private fun startAuto() {
        auto = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        reader.autoLabel = "自动 ${s.autoSec}秒/页"
        reader.invalidate()
        autoBtn.text = "停止"
        scheduleAuto()
        toast("自动阅读已开始，每 ${s.autoSec} 秒翻一页")
    }

    private fun stopAuto() {
        if (!auto) return
        auto = false
        handler.removeCallbacks(tick)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        reader.autoLabel = null
        reader.invalidate()
        autoBtn.text = "自动"
    }

    // ---------------- 底部菜单条 ----------------
    private fun buildMenuBar() {
        menuBar = LinearLayout(this)
        menuBar.orientation = LinearLayout.HORIZONTAL
        menuBar.visibility = View.GONE
        menuBar.background = box(WHITE, BLACK, 3)
        fun add(label: String, f: () -> Unit): TextView {
            val t = barBtn(label) { menuBar.visibility = View.GONE; f() }
            menuBar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
            return t
        }
        add("目录") { showToc() }
        add("字体") { openFontPanel() }
        add("设置") { panel.visibility = View.VISIBLE }
        autoBtn = add("自动") { if (auto) stopAuto() else startAuto() }
        add("转屏") { toggleOrientation(s) }
        add("书架") { finish() }
    }

    private fun barBtn(label: String, f: () -> Unit) = TextView(this).apply {
        text = label; textSize = 18f; gravity = Gravity.CENTER; setTextColor(BLACK)
        setPadding(0, dp(16), 0, dp(16))
        setOnClickListener { f() }
    }

    // ---------------- 目录 ----------------
    private fun showToc() {
        val chs = reader.chapters
        if (chs.isEmpty()) { toast("这本书没有目录"); return }
        val cur = reader.chapterIndex()
        val titles = chs.map { it.title }.toTypedArray()
        val dlg = AlertDialog.Builder(this).setTitle("目录（共 ${chs.size} 节）")
            .setSingleChoiceItems(titles, cur) { d, i -> reader.jumpTo(chs[i].offset); d.dismiss() }
            .create()
        dlg.show()
        dlg.listView.setSelection(max(0, cur - 2))
    }

    // ---------------- 面板通用 ----------------
    private fun makePanel(col: View): ScrollView {
        val sv = ScrollView(this)
        sv.visibility = View.GONE
        sv.background = box(WHITE, BLACK, 3)
        sv.addView(col)
        return sv
    }

    private fun newColumn(): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(8), dp(16), dp(24))
        return col
    }

    private fun panelHead(title: String): View {
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(TextView(this).apply {
            text = title; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(BLACK)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(TextView(this).apply {
            text = "完成"; textSize = 18f; setTextColor(BLACK); background = box(WHITE, BLACK)
            setPadding(dp(18), dp(8), dp(18), dp(8))
            setOnClickListener { closePanels() }
        })
        return head
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(BLACK)
        setPadding(0, dp(14), 0, dp(4))
    }

    private fun smallButton(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 17f; gravity = Gravity.CENTER
        setTextColor(BLACK); background = box(WHITE, BLACK)
        setPadding(0, dp(10), 0, dp(10))
        setOnClickListener { f() }
    }

    // ---------------- 设置面板 ----------------
    private fun buildSettingsPanel() {
        val col = newColumn()
        col.addView(panelHead("阅读设置"))

        col.addView(seek("字号", 24, 90, s.textSize.toInt(), { "$it" }) { s.textSize = it.toFloat(); applySettings() })
        col.addView(seek("粗细", 0, 10, s.weight, { if (it == 0) "标准" else "加粗 $it" }) { s.weight = it; applySettings() })
        col.addView(seek("字间距", 0, 40, s.letterSpace, { if (it == 0) "默认" else "+$it" }) { s.letterSpace = it; applySettings() })
        col.addView(seek("行距", 0, 80, s.lineExtra.toInt(), { "$it" }) { s.lineExtra = it.toFloat(); applySettings() })
        col.addView(seek("页边距", 16, 140, s.margin, { "$it" }) { s.margin = it; applySettings() })

        col.addView(label("字体平滑"))
        col.addView(Chips(listOf("开启", "关闭（更锐利）"), if (s.smooth) 0 else 1) {
            s.smooth = it == 0; applySettings()
        }.view)

        col.addView(label("下划线"))
        col.addView(Chips(listOf("无", "实线", "虚线", "点线", "点划线"), s.underline) {
            s.underline = it; applySettings()
        }.view)

        col.addView(label("阅读背景"))
        bgChips = Chips(listOf("纯白", "米黄", "护眼绿", "图片"), s.bgMode) { i ->
            if (i == 3 && !bgFile().exists()) {
                bgChips.select(s.bgMode)
                pickImage()
            } else {
                s.bgMode = i; applySettings()
            }
        }
        col.addView(bgChips.view)
        col.addView(smallButton("选择 / 更换背景图片…") { pickImage() },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        col.addView(seek("背景图浓度", 10, 100, s.bgAlpha, { "$it%" }) { s.bgAlpha = it; applySettings() })

        col.addView(label("翻页动画"))
        col.addView(Chips(listOf("无动画", "卷页（仿纸质）"), s.flip) { s.flip = it; applySettings() }.view)

        col.addView(seek("自动阅读：每页停留", 3, 120, s.autoSec, { "$it 秒" }) {
            s.autoSec = it
            if (auto) { reader.autoLabel = "自动 ${it}秒/页"; reader.invalidate(); scheduleAuto() }
        })

        col.addView(label("整屏刷新（清残影，每隔几页）"))
        val opts = listOf(0, 5, 10, 20)
        col.addView(Chips(listOf("关", "5页", "10页", "20页"), max(0, opts.indexOf(s.refreshEvery))) {
            s.refreshEvery = opts[it]; applySettings()
        }.view)

        panel = makePanel(col)
    }

    private fun seek(title: String, lo: Int, hi: Int, value: Int, fmt: (Int) -> String, done: (Int) -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(8), 0, 0)
        val tv = TextView(this)
        tv.textSize = 16f
        tv.setTextColor(BLACK)
        tv.text = "$title：${fmt(value)}"
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = value - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(p: SeekBar, v: Int, user: Boolean) { tv.text = "$title：${fmt(v + lo)}" }
            override fun onStartTrackingTouch(p: SeekBar) {}
            override fun onStopTrackingTouch(p: SeekBar) { done(p.progress + lo) }
        })
        box.addView(tv)
        box.addView(sb, LinearLayout.LayoutParams(MATCH, WRAP))
        return box
    }

    inner class Chips(private val labels: List<String>, private var sel: Int, private val onPick: (Int) -> Unit) {
        val view = LinearLayout(this@ReaderActivity)
        private val tvs = ArrayList<TextView>()

        init {
            view.orientation = LinearLayout.HORIZONTAL
            labels.forEachIndexed { i, label ->
                val tv = TextView(this@ReaderActivity)
                tv.text = label
                tv.textSize = 16f
                tv.gravity = Gravity.CENTER
                tv.setPadding(0, dp(10), 0, dp(10))
                tv.setOnClickListener { sel = i; refresh(); onPick(i) }
                tvs.add(tv)
                view.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            refresh()
        }

        private fun refresh() {
            tvs.forEachIndexed { i, tv ->
                if (i == sel) { tv.background = box(BLACK, BLACK); tv.setTextColor(WHITE) }
                else { tv.background = box(WHITE, BLACK); tv.setTextColor(BLACK) }
            }
        }

        fun select(i: Int) { sel = i; refresh() }
    }

    // ---------------- 字体面板 ----------------
    private fun buildFontPanel() {
        val col = newColumn()
        col.addView(panelHead("字体"))
        fontHint = TextView(this)
        fontHint.textSize = 14f
        fontHint.setTextColor(0xFF444444.toInt())
        fontHint.setPadding(0, dp(8), 0, dp(4))
        col.addView(fontHint)
        col.addView(smallButton("刷新字体列表") { rebuildFonts() },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(4) })
        fontList = LinearLayout(this)
        fontList.orientation = LinearLayout.VERTICAL
        col.addView(fontList)
        fontPanel = makePanel(col)
    }

    private fun hasStoragePermission() = Build.VERSION.SDK_INT < 23 ||
        (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)

    private fun openFontPanel() {
        if (!hasStoragePermission()) {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_PERM)
        }
        rebuildFonts()
        fontPanel.visibility = View.VISIBLE
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == REQ_PERM) rebuildFonts()
    }

    private fun rebuildFonts() {
        fontList.removeAllViews()
        fontItems.clear()
        val files = Fonts.scan()
        fontHint.text = "把 .ttf / .otf / .ttc 字体文件放进这个文件夹，再点「刷新字体列表」：\n${Fonts.dir().path}" +
            (if (files == null) "\n\n现在读不到这个文件夹：请先在文件管理里创建它，或到 系统设置 → 应用 → 劝读 → 权限，打开「存储」权限。" else "")

        val entries = ArrayList<Pair<String, String>>()
        entries.add("serif" to "系统衬线（默认）")
        entries.add("sans" to "系统黑体")
        entries.add("mono" to "等宽")
        files?.forEach { entries.add("path:${it.path}" to it.nameWithoutExtension) }

        for ((key, name) in entries) {
            val tv = TextView(this)
            tv.text = name
            tv.textSize = 19f
            tv.setPadding(dp(12), dp(12), dp(12), dp(12))
            tv.setOnClickListener {
                s.fontKey = key
                applySettings()
                paintFontItems()
            }
            fontItems.add(key to tv)
            fontList.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        }
        if (files != null && files.isEmpty()) {
            fontList.addView(TextView(this).apply {
                text = "文件夹里还没有字体文件"; textSize = 15f; setTextColor(0xFF444444.toInt())
                setPadding(0, dp(10), 0, 0)
            })
        }
        paintFontItems()
    }

    private fun paintFontItems() {
        for ((key, tv) in fontItems) {
            val on = key == s.fontKey
            val base = tv.text.toString().removePrefix("✓ ")
            tv.text = if (on) "✓ $base" else base
            tv.setTextColor(if (on) WHITE else BLACK)
            tv.background = if (on) box(BLACK, BLACK) else box(WHITE, BLACK)
        }
    }

    // ---------------- 选背景图片（用本应用自带的文件浏览器）----------------
    private fun pickImage() {
        startActivityForResult(Intent(this, PickFileActivity::class.java)
            .putExtra("exts", arrayOf("jpg", "jpeg", "png", "webp", "bmp", "gif"))
            .putExtra("multi", false), REQ_BG)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (res != RESULT_OK || req != REQ_BG) return
        val path = data?.getStringArrayListExtra("paths")?.firstOrNull() ?: return
        try {
            File(path).copyTo(bgFile(), overwrite = true)
            reader.loadBgImage(bgFile().path)
            s.bgMode = 3
            bgChips.select(3)
            applySettings()
        } catch (e: Exception) {
            toast("失败：${e.message}")
        }
    }
}
