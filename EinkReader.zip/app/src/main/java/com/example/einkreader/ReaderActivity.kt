package com.example.einkreader

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.io.File
import kotlin.math.max

class ReaderActivity : Activity() {
    private lateinit var reader: ReaderView
    private lateinit var s: Settings
    private lateinit var shelf: Shelf
    private lateinit var bookId: String
    private lateinit var menuBar: LinearLayout
    private lateinit var panel: ScrollView
    private lateinit var fontBox: LinearLayout
    private lateinit var bgChips: Chips
    private val REQ_FONT = 1
    private val REQ_BG = 2

    private fun bgFile() = File(filesDir, "bg_image")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val id = intent.getStringExtra("id")
        if (id == null) { finish(); return }
        bookId = id
        s = Settings(this)
        shelf = Shelf(this)
        val tf = shelf.textFile(bookId)
        if (!tf.exists()) { finish(); return }

        // 横竖屏切换时直接跳变，不做淡入淡出，墨水屏上更干脆
        val wlp = window.attributes
        wlp.rotationAnimation = WindowManager.LayoutParams.ROTATION_ANIMATION_JUMPCUT
        window.attributes = wlp

        reader = ReaderView(this)
        buildMenuBar()
        buildPanel()
        val root = FrameLayout(this)
        root.addView(reader, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(menuBar, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        root.addView(panel, panelParams())
        setContentView(root)

        if (s.bgMode == 3 && !bgFile().exists()) s.bgMode = 0
        if (bgFile().exists()) reader.loadBgImage(bgFile().path)
        applySettings()
        reader.setBook(tf.readText(), shelf.readChapters(bookId), shelf.pos(bookId))
        reader.onMenu = { onCenterTap() }
        // 点设置面板以外的空白处：关闭面板
        reader.onTapIntercept = {
            if (panel.visibility == View.VISIBLE) { panel.visibility = View.GONE; true } else false
        }
        reader.onPage = {
            shelf.setPos(bookId, it)
            if (menuBar.visibility == View.VISIBLE) menuBar.visibility = View.GONE
        }
    }

    override fun onResume() { super.onResume(); hideSystemBars() }

    /** 竖屏：底部 55% 高；横屏：右侧 42% 宽、全高，左边留给正文预览 */
    private fun panelParams(): FrameLayout.LayoutParams {
        val dm = resources.displayMetrics
        return if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
            FrameLayout.LayoutParams((dm.widthPixels * 0.42).toInt(), MATCH, Gravity.END)
        else
            FrameLayout.LayoutParams(MATCH, (dm.heightPixels * 0.55).toInt(), Gravity.BOTTOM)
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (::panel.isInitialized) panel.layoutParams = panelParams()
        hideSystemBars()
    }

    override fun onPause() {
        super.onPause()
        if (::reader.isInitialized) shelf.setPos(bookId, reader.start)
    }

    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    override fun onKeyDown(k: Int, e: KeyEvent): Boolean = when (k) {
        KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> { reader.next(); true }
        KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_PAGE_UP -> { reader.prev(); true }
        else -> super.onKeyDown(k, e)
    }

    override fun onBackPressed() {
        when {
            panel.visibility == View.VISIBLE -> panel.visibility = View.GONE
            menuBar.visibility == View.VISIBLE -> menuBar.visibility = View.GONE
            else -> finish()
        }
    }

    private fun onCenterTap() {
        if (panel.visibility == View.VISIBLE) {
            panel.visibility = View.GONE
        } else {
            menuBar.visibility = if (menuBar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
    }

    // ---------------- 应用设置到阅读视图 ----------------
    private fun applySettings() {
        reader.typeface = Fonts.get(this, s.fontKey)
        reader.textSizePx = s.textSize
        reader.weight = s.weight
        reader.lineExtraPx = s.lineExtra
        reader.marginH = s.margin
        reader.underlineStyle = s.underline
        reader.bgMode = s.bgMode
        reader.bgAlpha = s.bgAlpha
        reader.fullRefreshEvery = s.refreshEvery
        reader.flipMode = s.flip
        reader.relayout()
    }

    // ---------------- 底部菜单条 ----------------
    private fun buildMenuBar() {
        menuBar = LinearLayout(this)
        menuBar.orientation = LinearLayout.HORIZONTAL
        menuBar.visibility = View.GONE
        menuBar.background = box(WHITE, BLACK, 3)
        menuBar.addView(barBtn("目录") { menuBar.visibility = View.GONE; showToc() }, LinearLayout.LayoutParams(0, WRAP, 1f))
        menuBar.addView(barBtn("设置") { menuBar.visibility = View.GONE; panel.visibility = View.VISIBLE }, LinearLayout.LayoutParams(0, WRAP, 1f))
        menuBar.addView(barBtn("书架") { finish() }, LinearLayout.LayoutParams(0, WRAP, 1f))
    }

    private fun barBtn(label: String, f: () -> Unit) = TextView(this).apply {
        text = label; textSize = 20f; gravity = Gravity.CENTER; setTextColor(BLACK)
        setPadding(0, dp(16), 0, dp(16))
        setOnClickListener { f() }
    }

    // ---------------- 目录 ----------------
    private fun showToc() {
        val chs = reader.chapters
        if (chs.isEmpty()) { toast("这本书没有目录"); return }
        val cur = reader.chapterIndex()
        val titles = chs.map { it.title }.toTypedArray()
        val dlg = AlertDialog.Builder(this).setTitle("目录（共 ${chs.size} 节）")
            .setSingleChoiceItems(titles, cur) { d, i -> reader.jumpTo(chs[i].offset); d.dismiss() }
            .create()
        dlg.show()
        dlg.listView.setSelection(max(0, cur - 2))
    }

    // ---------------- 设置面板 ----------------
    private fun buildPanel() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(8), dp(16), dp(24))

        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(TextView(this).apply {
            text = "阅读设置"; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(BLACK)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(TextView(this).apply {
            text = "完成"; textSize = 18f; setTextColor(BLACK); background = box(WHITE, BLACK)
            setPadding(dp(18), dp(8), dp(18), dp(8))
            setOnClickListener { panel.visibility = View.GONE }
        })
        col.addView(head)

        col.addView(label("字体（点一下立即预览，长按可删除导入的字体）"))
        fontBox = LinearLayout(this)
        fontBox.orientation = LinearLayout.VERTICAL
        col.addView(fontBox)
        rebuildFonts()

        col.addView(seek("字号", 24, 90, s.textSize.toInt(), { "$it" }) { s.textSize = it.toFloat(); applySettings() })
        col.addView(seek("粗细", 0, 10, s.weight, { if (it == 0) "标准" else "加粗 $it" }) { s.weight = it; applySettings() })
        col.addView(seek("行距", 0, 80, s.lineExtra.toInt(), { "$it" }) { s.lineExtra = it.toFloat(); applySettings() })
        col.addView(seek("页边距", 16, 140, s.margin, { "$it" }) { s.margin = it; applySettings() })

        col.addView(label("下划线"))
        col.addView(Chips(listOf("无", "实线", "虚线"), s.underline) { s.underline = it; applySettings() }.view)

        col.addView(label("阅读背景"))
        bgChips = Chips(listOf("纯白", "米黄", "护眼绿", "图片"), s.bgMode) { i ->
            if (i == 3 && !bgFile().exists()) {
                bgChips.select(s.bgMode)
                pickImage()
            } else {
                s.bgMode = i; applySettings()
            }
        }
        col.addView(bgChips.view)
        col.addView(TextView(this).apply {
            text = "选择 / 更换背景图片…"; textSize = 17f; gravity = Gravity.CENTER
            setTextColor(BLACK); background = box(WHITE, BLACK)
            setPadding(0, dp(10), 0, dp(10))
            setOnClickListener { pickImage() }
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        col.addView(seek("背景图浓度", 10, 100, s.bgAlpha, { "$it%" }) { s.bgAlpha = it; applySettings() })

        col.addView(label("翻页动画"))
        col.addView(Chips(listOf("无动画", "卷页（仿纸质）"), s.flip) { s.flip = it; applySettings() }.view)

        col.addView(label("整屏刷新（清残影，每隔几页）"))
        val opts = listOf(0, 5, 10, 20)
        col.addView(Chips(listOf("关", "5页", "10页", "20页"), max(0, opts.indexOf(s.refreshEvery))) {
            s.refreshEvery = opts[it]; applySettings()
        }.view)

        panel = ScrollView(this)
        panel.visibility = View.GONE
        panel.background = box(WHITE, BLACK, 3)
        panel.addView(col)
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(BLACK)
        setPadding(0, dp(14), 0, dp(4))
    }

    private fun seek(title: String, lo: Int, hi: Int, value: Int, fmt: (Int) -> String, done: (Int) -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(8), 0, 0)
        val tv = TextView(this)
        tv.textSize = 16f
        tv.setTextColor(BLACK)
        tv.text = "$title：${fmt(value)}"
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = value - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(p: SeekBar, v: Int, user: Boolean) { tv.text = "$title：${fmt(v + lo)}" }
            override fun onStartTrackingTouch(p: SeekBar) {}
            override fun onStopTrackingTouch(p: SeekBar) { done(p.progress + lo) }
        })
        box.addView(tv)
        box.addView(sb, LinearLayout.LayoutParams(MATCH, WRAP))
        return box
    }

    inner class Chips(private val labels: List<String>, private var sel: Int, private val onPick: (Int) -> Unit) {
        val view = LinearLayout(this@ReaderActivity)
        private val tvs = ArrayList<TextView>()

        init {
            view.orientation = LinearLayout.HORIZONTAL
            labels.forEachIndexed { i, label ->
                val tv = TextView(this@ReaderActivity)
                tv.text = label
                tv.textSize = 16f
                tv.gravity = Gravity.CENTER
                tv.setPadding(0, dp(10), 0, dp(10))
                tv.setOnClickListener { sel = i; refresh(); onPick(i) }
                tvs.add(tv)
                view.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            refresh()
        }

        private fun refresh() {
            tvs.forEachIndexed { i, tv ->
                if (i == sel) { tv.background = box(BLACK, BLACK); tv.setTextColor(WHITE) }
                else { tv.background = box(WHITE, BLACK); tv.setTextColor(BLACK) }
            }
        }

        fun select(i: Int) { sel = i; refresh() }
    }

    // ---------------- 字体列表 ----------------
    private fun rebuildFonts() {
        fontBox.removeAllViews()
        val entries = ArrayList<Pair<String, String>>()
        entries.add("serif" to "系统衬线")
        entries.add("sans" to "系统黑体")
        entries.add("mono" to "等宽")
        for (f in Fonts.list(this)) entries.add("file:${f.name}" to f.name.substringBeforeLast('.'))

        for ((key, name) in entries) {
            val on = key == s.fontKey
            val tv = TextView(this)
            tv.text = (if (on) "✓ " else "　") + name + "　春风又绿江南岸 Aa"
            tv.textSize = 20f
            tv.setTextColor(if (on) WHITE else BLACK)
            tv.background = if (on) box(BLACK, BLACK) else box(WHITE, BLACK)
            tv.typeface = Fonts.get(this, key)
            tv.setPadding(dp(12), dp(10), dp(12), dp(10))
            tv.setOnClickListener { s.fontKey = key; applySettings(); rebuildFonts() }
            if (key.startsWith("file:")) tv.setOnLongClickListener { confirmDeleteFont(key, name); true }
            fontBox.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        }
        val add = TextView(this)
        add.text = "＋ 导入字体文件 (.ttf / .otf)"
        add.textSize = 17f
        add.gravity = Gravity.CENTER
        add.setTextColor(BLACK)
        add.background = box(WHITE, BLACK)
        add.setPadding(0, dp(12), 0, dp(12))
        add.setOnClickListener { pickFont() }
        fontBox.addView(add, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
    }

    private fun confirmDeleteFont(key: String, name: String) {
        AlertDialog.Builder(this).setMessage("删除字体「$name」？")
            .setPositiveButton("删除") { _, _ ->
                Fonts.delete(this, key)
                if (s.fontKey == key) { s.fontKey = "serif"; applySettings() }
                rebuildFonts()
            }.setNegativeButton("取消", null).show()
    }

    // ---------------- 选文件（用本应用自带的文件浏览器）----------------
    private fun pickImage() = pickFile(arrayOf("jpg", "jpeg", "png", "webp", "bmp", "gif"), REQ_BG)
    private fun pickFont() = pickFile(arrayOf("ttf", "otf", "ttc"), REQ_FONT)

    private fun pickFile(exts: Array<String>, req: Int) {
        startActivityForResult(Intent(this, PickFileActivity::class.java)
            .putExtra("exts", exts).putExtra("multi", false), req)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (res != RESULT_OK) return
        val path = data?.getStringArrayListExtra("paths")?.firstOrNull() ?: return
        try {
            val f = File(path)
            if (req == REQ_FONT) importFont(f) else if (req == REQ_BG) importBg(f)
        } catch (e: Exception) {
            toast("失败：${e.message}")
        }
    }

    private fun importFont(src: File) {
        val name = src.name.replace(Regex("[^\\w.\\u4e00-\\u9fa5-]"), "_")
        val f = File(Fonts.dir(this), name)
        src.copyTo(f, overwrite = true)
        val key = "file:$name"
        Fonts.forget(key)
        val tf = try { Typeface.createFromFile(f) } catch (e: Exception) { null }
        if (tf == null || tf == Typeface.DEFAULT) {
            f.delete(); toast("这个文件不是可用的字体"); return
        }
        s.fontKey = key
        applySettings()
        rebuildFonts()
    }

    private fun importBg(src: File) {
        src.copyTo(bgFile(), overwrite = true)
        reader.loadBgImage(bgFile().path)
        s.bgMode = 3
        bgChips.select(3)
        applySettings()
    }
}
