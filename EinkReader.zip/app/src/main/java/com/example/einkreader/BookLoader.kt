package com.example.einkreader

import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.CharBuffer
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.zip.ZipFile
import kotlin.math.max
import kotlin.math.min

class Chapter(val offset: Int, val title: String)
class Imported(val length: Int, val chapters: List<Chapter>)

/**
 * 导入：边解析边把纯文字写进 out，整本书不会同时放在内存里。
 * EPUB 用 ZipFile 只读需要的 HTML，图片之类完全不读。
 */
object BookLoader {
    private const val INDENT = "\u3000\u3000"
    private val chapRe = Regex(
        "^(第[0-9零一二三四五六七八九十百千万两〇]+[章回节卷集部篇].{0,30}|" +
        "[Cc]hapter\\s*[0-9IVXivx]+.{0,30}|序章.{0,20}|楔子.{0,20}|引子.{0,20}|" +
        "尾声.{0,20}|番外.{0,30}|后记.{0,20}|前言.{0,20})$")
    private val ncxRe = Regex("(?is)<navLabel[^>]*>\\s*<text[^>]*>(.*?)</text>.*?<content[^>]*src\\s*=\\s*\"([^\"]*)\"")
    private val navRe = Regex("(?is)<a\\s[^>]*href\\s*=\\s*\"([^\"]*)\"[^>]*>(.*?)</a>")

    private fun isWs(ch: Char) = ch.isWhitespace() || ch == '\u3000' || ch == '\u00A0'

    /** 写文字的出口：记录位置，顺便记下“每约 8000 字一段”的备用目录点 */
    private class Sink(file: File) {
        private val w = BufferedWriter(OutputStreamWriter(FileOutputStream(file), Charsets.UTF_8), 1 shl 16)
        var pos = 0
            private set
        private var any = false
        val pseudo = ArrayList<Int>()
        private var lastPseudo = -100000

        fun line(t: String): Int {
            if (any) { w.write(10); pos++ }
            val start = pos
            if (start - lastPseudo >= 8000) { pseudo.add(start); lastPseudo = start }
            w.write(INDENT)
            w.write(t)
            pos += 2 + t.length
            any = true
            return start
        }

        fun close() = w.close()
    }

    /** 控制进度回调频率：每 5% 才通知一次，避免墨水屏上频繁刷新 */
    private class Reporter(val cb: (Int) -> Unit) {
        private var last = -1
        fun report(pct: Int) {
            val b = pct / 5
            if (b != last) { last = b; cb(pct) }
        }
    }

    private class CountIn(ins: InputStream) : FilterInputStream(ins) {
        var n = 0L
        override fun read(): Int { val r = super.read(); if (r >= 0) n++; return r }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val r = super.read(b, off, len); if (r > 0) n += r; return r
        }
    }

    fun importBook(src: File, out: File, progress: (Int) -> Unit): Imported {
        val sink = Sink(out)
        val rep = Reporter(progress)
        try {
            val chs = if (isZip(src)) epub(src, sink, rep) else txt(src, sink, rep)
            sink.close()
            return finish(sink, chs)
        } catch (t: Throwable) {
            try { sink.close() } catch (e: Throwable) {}
            out.delete()
            throw t
        }
    }

    private fun isZip(f: File): Boolean = FileInputStream(f).use {
        val a = it.read(); val b = it.read()
        a == 'P'.code && b == 'K'.code
    }

    private fun finish(sink: Sink, chs: List<Chapter>): Imported {
        val len = sink.pos
        if (chs.size >= 2) {
            val list = if (chs[0].offset > 0) listOf(Chapter(0, "开篇")) + chs else chs
            return Imported(len, list)
        }
        // 没识别出章节：按约 8000 字自动分段
        val out = ArrayList<Chapter>()
        sink.pseudo.forEachIndexed { i, off ->
            out.add(Chapter(off, "第 ${i + 1} 部分（${off * 100L / max(1, len)}%）"))
        }
        return Imported(len, out)
    }

    // ---------------- TXT ----------------
    private fun detectCharset(f: File): Charset {
        val buf = ByteArray(min(f.length(), 262144L).toInt())
        FileInputStream(f).use {
            var o = 0
            while (o < buf.size) {
                val n = it.read(buf, o, buf.size - o)
                if (n < 0) break
                o += n
            }
        }
        if (buf.size >= 2 && buf[0] == 0xFF.toByte() && buf[1] == 0xFE.toByte()) return Charsets.UTF_16LE
        if (buf.size >= 2 && buf[0] == 0xFE.toByte() && buf[1] == 0xFF.toByte()) return Charsets.UTF_16BE
        val dec = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        val res = dec.decode(ByteBuffer.wrap(buf), CharBuffer.allocate(buf.size + 1), false)
        return if (res.isError) Charset.forName("GB18030") else Charsets.UTF_8
    }

    private fun txt(src: File, sink: Sink, rep: Reporter): List<Chapter> {
        val cs = detectCharset(src)
        val chs = ArrayList<Chapter>()
        val total = max(1L, src.length())
        val cin = CountIn(FileInputStream(src))
        BufferedReader(InputStreamReader(cin, cs), 1 shl 16).use { r ->
            var first = true
            while (true) {
                var line = r.readLine() ?: break
                if (first) { first = false; if (line.startsWith("\uFEFF")) line = line.substring(1) }
                val t = line.trim { isWs(it) }
                if (t.isEmpty()) continue
                val start = sink.line(t)
                if (t.length <= 40 && chapRe.matches(t)) chs.add(Chapter(start, t))
                rep.report((cin.n * 100 / total).toInt())
            }
        }
        return chs
    }

    // ---------------- EPUB ----------------
    private class Item(val href: String, val type: String, val props: String)

    private fun epub(src: File, sink: Sink, rep: Reporter): List<Chapter> {
        val chs = ArrayList<Chapter>()
        ZipFile(src).use { zf ->
            fun read(name: String): ByteArray? {
                val e = zf.getEntry(name) ?: return null
                return zf.getInputStream(e).use { it.readBytes() }
            }
            /** href 可能带 %XX 转义，两种写法都试一下，返回压缩包里真实存在的路径 */
            fun find(base: String, href: String): String? {
                val a = resolve(base + decode(href))
                if (zf.getEntry(a) != null) return a
                val b = resolve(base + href)
                return if (zf.getEntry(b) != null) b else null
            }

            val container = read("META-INF/container.xml") ?: throw Exception("不是有效的 EPUB")
            var opfPath = ""
            parse(container) { p ->
                if (p.eventType == XmlPullParser.START_TAG && p.name == "rootfile" && opfPath.isEmpty())
                    opfPath = p.getAttributeValue(null, "full-path") ?: ""
            }
            val opf = read(opfPath) ?: throw Exception("找不到 EPUB 目录文件")
            val base = if (opfPath.contains('/')) opfPath.substringBeforeLast('/') + "/" else ""

            val manifest = HashMap<String, Item>()
            val spine = ArrayList<String>()
            parse(opf) { p ->
                if (p.eventType == XmlPullParser.START_TAG) {
                    when (p.name) {
                        "item" -> manifest[p.getAttributeValue(null, "id") ?: ""] = Item(
                            p.getAttributeValue(null, "href") ?: "",
                            p.getAttributeValue(null, "media-type") ?: "",
                            p.getAttributeValue(null, "properties") ?: "")
                        "itemref" -> spine.add(p.getAttributeValue(null, "idref") ?: "")
                    }
                }
            }

            // 目录标题：文件路径 -> 标题
            val titles = HashMap<String, String>()
            fun readToc(item: Item, ncx: Boolean) {
                val path = find(base, item.href.substringBefore('#')) ?: return
                val data = read(path) ?: return
                val tbase = if (path.contains('/')) path.substringBeforeLast('/') + "/" else ""
                val s = String(data, Charsets.UTF_8)
                for (m in (if (ncx) ncxRe else navRe).findAll(s)) {
                    val title = clean(m.groupValues[if (ncx) 1 else 2])
                    val href = m.groupValues[if (ncx) 2 else 1]
                    if (title.isEmpty() || href.isEmpty() || href.startsWith("#")) continue
                    val target = find(tbase, href.substringBefore('#')) ?: continue
                    if (!titles.containsKey(target)) titles[target] = title
                }
            }
            for (item in manifest.values) if (item.type == "application/x-dtbncx+xml") readToc(item, true)
            for (item in manifest.values) if (item.props.split(' ').contains("nav")) readToc(item, false)

            val useToc = titles.isNotEmpty()
            val n = max(1, spine.size)
            val buf = CharArray(16384)
            for ((idx, id) in spine.withIndex()) {
                rep.report(idx * 100 / n)
                val item = manifest[id] ?: continue
                if (item.type.isNotEmpty() && !item.type.contains("html") && !item.type.contains("xml")) continue
                val path = find(base, item.href.substringBefore('#')) ?: continue
                var itemStart = -1
                var firstLine = ""
                val ex = HtmlExtractor { line ->
                    val st = sink.line(line)
                    if (itemStart < 0) { itemStart = st; firstLine = line }
                }
                zf.getInputStream(zf.getEntry(path)).use { ins ->
                    val r = InputStreamReader(ins, Charsets.UTF_8)
                    while (true) {
                        val k = r.read(buf)
                        if (k < 0) break
                        ex.feed(buf, k)
                    }
                }
                ex.finish()
                if (itemStart < 0) continue
                val t = titles[path]
                if (t != null) chs.add(Chapter(itemStart, t))
                else if (!useToc) chs.add(Chapter(itemStart, firstLine.take(24)))
            }
        }
        return chs
    }

    private fun clean(s: String): String {
        val parts = ArrayList<String>()
        val ex = HtmlExtractor { parts.add(it) }
        val arr = s.toCharArray()
        ex.feed(arr, arr.size)
        ex.finish()
        return parts.joinToString(" ").trim()
    }

    private fun decode(h: String): String = try {
        URLDecoder.decode(h.replace("+", "%2B"), "UTF-8")
    } catch (e: Exception) { h }

    private fun resolve(path: String): String {
        val out = ArrayList<String>()
        for (s in path.split('/')) {
            if (s == "" || s == ".") continue
            if (s == "..") { if (out.isNotEmpty()) out.removeAt(out.size - 1) } else out.add(s)
        }
        return out.joinToString("/")
    }

    private fun parse(data: ByteArray, onEvent: (XmlPullParser) -> Unit) {
        val p = XmlPullParserFactory.newInstance().newPullParser()
        p.setInput(ByteArrayInputStream(data), null)
        while (p.eventType != XmlPullParser.END_DOCUMENT) { onEvent(p); p.next() }
    }

    /**
     * 一遍扫完的 HTML 转文字：逐字符状态机，边读边出“段落”，
     * 比多次正则替换快得多，也不会生成一堆整本书大小的临时字符串。
     */
    private class HtmlExtractor(private val sink: (String) -> Unit) {
        private val cur = StringBuilder()
        private val tag = StringBuilder()
        private val ent = StringBuilder()
        private var inTag = false
        private var inEnt = false
        private var sp = true
        private var pre = false
        private var skipName: String? = null

        fun feed(buf: CharArray, n: Int) { for (i in 0 until n) ch(buf[i]) }

        fun finish() { abortEntity(); flush() }

        private fun ch(c: Char) {
            if (inTag) {
                if (c == '>') { inTag = false; endTag() }
                else if (tag.length < 80) tag.append(c)
                return
            }
            if (c == '<') { abortEntity(); inTag = true; tag.setLength(0); return }
            if (skipName != null) return
            if (inEnt) {
                if (c == ';') {
                    inEnt = false
                    val r = entity(ent.toString())
                    if (r != null) { for (x in r) text(x) }
                    else { text('&'); for (x in ent) text(x); text(';') }
                    ent.setLength(0)
                    return
                }
                if ((c.isLetterOrDigit() || c == '#') && ent.length < 12) { ent.append(c); return }
                abortEntity()
            }
            if (c == '&') { inEnt = true; ent.setLength(0); return }
            text(c)
        }

        private fun abortEntity() {
            if (inEnt) {
                inEnt = false
                text('&')
                for (x in ent) text(x)
                ent.setLength(0)
            }
        }

        private fun text(c: Char) {
            if (c == '\uFEFF') return
            if (pre && c == '\n') { flush(); return }
            if (c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == '\u00A0' || c == '\u3000') {
                if (cur.isNotEmpty() && !sp) { cur.append(' '); sp = true }
            } else {
                cur.append(c); sp = false
            }
        }

        private fun flush() {
            var end = cur.length
            while (end > 0 && cur[end - 1] == ' ') end--
            if (end > 0) sink(cur.substring(0, end))
            cur.setLength(0)
            sp = true
        }

        private fun endTag() {
            val s = tag.toString()
            if (s.startsWith("!") || s.startsWith("?")) return
            val closing = s.startsWith("/")
            val st = if (closing) 1 else 0
            var i = st
            while (i < s.length && s[i].isLetterOrDigit()) i++
            val name = s.substring(st, i).lowercase()
            val selfClose = s.endsWith("/")
            val sk = skipName
            if (sk != null) { if (closing && name == sk) skipName = null; return }
            if (!closing && !selfClose && (name == "script" || name == "style" || name == "head")) {
                skipName = name; return
            }
            when (name) {
                "p", "div", "br", "h1", "h2", "h3", "h4", "h5", "h6", "li", "tr",
                "section", "article", "blockquote", "title" -> flush()
                "pre" -> { flush(); pre = !closing }
            }
        }

        private fun entity(e: String): String? = when {
            e.startsWith("#x") || e.startsWith("#X") -> cp(e.substring(2).toIntOrNull(16))
            e.startsWith("#") -> cp(e.substring(1).toIntOrNull())
            else -> when (e) {
                "nbsp" -> " "; "amp" -> "&"; "lt" -> "<"; "gt" -> ">"
                "quot" -> "\""; "apos" -> "'"; "mdash" -> "—"; "ndash" -> "–"
                "hellip" -> "…"; "ldquo" -> "“"; "rdquo" -> "”"
                "lsquo" -> "‘"; "rsquo" -> "’"
                else -> null
            }
        }

        private fun cp(n: Int?): String? =
            if (n != null && n in 1..0x10FFFF) String(Character.toChars(n)) else null
    }
}
