package com.example.einkreader

import android.text.Html
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.ByteArrayInputStream
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.zip.ZipInputStream

object BookLoader {

    /** 根据内容判断 TXT / EPUB，返回排版好的纯文本 */
    fun load(bytes: ByteArray): String {
        val isZip = bytes.size > 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()
        val raw = if (isZip) epubToText(bytes) else decodeText(bytes)
        return normalize(raw)
    }

    private fun decodeText(b: ByteArray): String {
        var off = 0
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte()) off = 3
        val buf = ByteBuffer.wrap(b, off, b.size - off)
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(buf).toString()
        } catch (e: CharacterCodingException) {
            String(b, off, b.size - off, Charset.forName("GB18030"))
        }
    }

    private fun epubToText(bytes: ByteArray): String {
        val files = HashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                if (!e.isDirectory) files[e.name] = zin.readBytes()
            }
        }
        // 1. container.xml -> opf 路径
        val container = files["META-INF/container.xml"] ?: return decodeText(bytes)
        var opfPath = ""
        parse(container) { p ->
            if (p.eventType == XmlPullParser.START_TAG && p.name == "rootfile" && opfPath.isEmpty())
                opfPath = p.getAttributeValue(null, "full-path") ?: ""
        }
        val opf = files[opfPath] ?: return ""
        val base = if (opfPath.contains('/')) opfPath.substringBeforeLast('/') + "/" else ""
        // 2. manifest + spine
        val manifest = HashMap<String, String>()
        val spine = ArrayList<String>()
        parse(opf) { p ->
            if (p.eventType == XmlPullParser.START_TAG) {
                when (p.name) {
                    "item" -> manifest[p.getAttributeValue(null, "id") ?: ""] =
                        p.getAttributeValue(null, "href") ?: ""
                    "itemref" -> spine.add(p.getAttributeValue(null, "idref") ?: "")
                }
            }
        }
        // 3. 按 spine 顺序取 HTML 转文本
        val sb = StringBuilder()
        for (id in spine) {
            val href = manifest[id] ?: continue
            val path = resolve(base + URLDecoder.decode(href.substringBefore('#'), "UTF-8"))
            val data = files[path] ?: continue
            val html = String(data, Charsets.UTF_8)
                .replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), "")
            val t = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString()
            sb.append(t).append("\n\n")
        }
        return sb.toString()
    }

    private fun resolve(path: String): String {
        val out = ArrayList<String>()
        for (s in path.split('/')) {
            when (s) { "", "." -> {} ".." -> if (out.isNotEmpty()) out.removeAt(out.size - 1) else -> out.add(s) }
        }
        return out.joinToString("/")
    }

    private fun parse(data: ByteArray, onEvent: (XmlPullParser) -> Unit) {
        val p = XmlPullParserFactory.newInstance().newPullParser()
        p.setInput(ByteArrayInputStream(data), null)
        while (p.eventType != XmlPullParser.END_DOCUMENT) { onEvent(p); p.next() }
    }

    /** 去掉空行，每段首行缩进两个全角空格 */
    private fun normalize(s: String): String {
        val sb = StringBuilder()
        for (line in s.replace("\r", "").replace('\uFFFC', ' ').split('\n')) {
            val t = line.trim { it.isWhitespace() || it == '\u3000' || it == '\u00A0' }
            if (t.isEmpty()) continue
            if (sb.isNotEmpty()) sb.append('\n')
            sb.append("\u3000\u3000").append(t)
        }
        return sb.toString()
    }
}
