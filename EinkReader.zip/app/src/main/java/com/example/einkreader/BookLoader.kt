package com.example.einkreader

import android.text.Html
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.ByteArrayInputStream
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.zip.ZipInputStream
import kotlin.math.max

class Chapter(val offset: Int, val title: String)
class Parsed(val text: String, val chapters: List<Chapter>)

object BookLoader {
    private const val INDENT = "\u3000\u3000"
    private val chapRe = Regex(
        "^(第[0-9零一二三四五六七八九十百千万两〇]+[章回节卷集部篇].{0,30}|" +
        "[Cc]hapter\\s*[0-9IVXivx]+.{0,30}|序章.{0,20}|楔子.{0,20}|引子.{0,20}|" +
        "尾声.{0,20}|番外.{0,30}|后记.{0,20}|前言.{0,20})$")
    private val tagRe = Regex("<[^>]+>")
    private val spaceRe = Regex("\\s+")
    private val headRe = Regex("(?is)<head[^>]*>.*?</head>")
    private val scriptRe = Regex("(?is)<(script|style)[^>]*>.*?</\\1>")
    private val ncxRe = Regex("(?is)<navLabel[^>]*>\\s*<text[^>]*>(.*?)</text>.*?<content[^>]*src\\s*=\\s*\"([^\"]*)\"")
    private val navRe = Regex("(?is)<a\\s[^>]*href\\s*=\\s*\"([^\"]*)\"[^>]*>(.*?)</a>")

    fun load(bytes: ByteArray): Parsed {
        val isZip = bytes.size > 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()
        return if (isZip) epub(bytes) else txt(decodeText(bytes))
    }

    private fun isWs(ch: Char) = ch.isWhitespace() || ch == '\u3000' || ch == '\u00A0'

    // ---------------- TXT ----------------
    private fun txt(raw: String): Parsed {
        val sb = StringBuilder()
        val chs = ArrayList<Chapter>()
        for (line in raw.replace("\r", "").split('\n')) {
            val t = line.trim { isWs(it) }
            if (t.isEmpty()) continue
            if (sb.isNotEmpty()) sb.append('\n')
            if (t.length <= 40 && chapRe.matches(t)) chs.add(Chapter(sb.length, t))
            sb.append(INDENT).append(t)
        }
        return finish(sb.toString(), chs)
    }

    private fun decodeText(b: ByteArray): String {
        var off = 0
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte()) off = 3
        val buf = ByteBuffer.wrap(b, off, b.size - off)
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(buf).toString()
        } catch (e: CharacterCodingException) {
            String(b, off, b.size - off, Charset.forName("GB18030"))
        }
    }

    /** 章节少于 2 个时，按约 8000 字自动分段做目录 */
    private fun finish(text: String, chs: List<Chapter>): Parsed {
        if (chs.size >= 2) {
            return if (chs[0].offset > 0) Parsed(text, listOf(Chapter(0, "开篇")) + chs) else Parsed(text, chs)
        }
        val out = ArrayList<Chapter>()
        var i = 0
        var n = 1
        while (i < text.length) {
            out.add(Chapter(i, "第 $n 部分（${i * 100L / max(1, text.length)}%）"))
            val j = if (i + 8000 >= text.length) -1 else text.indexOf('\n', i + 8000)
            if (j < 0) break
            i = j + 1
            n++
        }
        return Parsed(text, out)
    }

    // ---------------- EPUB ----------------
    private class Item(val href: String, val type: String, val props: String)

    private fun epub(bytes: ByteArray): Parsed {
        val files = HashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                if (!e.isDirectory) files[e.name] = zin.readBytes()
            }
        }
        val container = files["META-INF/container.xml"] ?: return Parsed("", emptyList())
        var opfPath = ""
        parse(container) { p ->
            if (p.eventType == XmlPullParser.START_TAG && p.name == "rootfile" && opfPath.isEmpty())
                opfPath = p.getAttributeValue(null, "full-path") ?: ""
        }
        val opf = files[opfPath] ?: return Parsed("", emptyList())
        val base = if (opfPath.contains('/')) opfPath.substringBeforeLast('/') + "/" else ""

        val manifest = HashMap<String, Item>()
        val spine = ArrayList<String>()
        parse(opf) { p ->
            if (p.eventType == XmlPullParser.START_TAG) {
                when (p.name) {
                    "item" -> manifest[p.getAttributeValue(null, "id") ?: ""] = Item(
                        p.getAttributeValue(null, "href") ?: "",
                        p.getAttributeValue(null, "media-type") ?: "",
                        p.getAttributeValue(null, "properties") ?: "")
                    "itemref" -> spine.add(p.getAttributeValue(null, "idref") ?: "")
                }
            }
        }

        // 目录标题：文件路径 -> 标题
        val titles = HashMap<String, String>()
        fun readToc(item: Item, ncx: Boolean) {
            val path = resolve(base + decode(item.href.substringBefore('#')))
            val data = files[path] ?: return
            val tbase = if (path.contains('/')) path.substringBeforeLast('/') + "/" else ""
            val s = String(data, Charsets.UTF_8)
            val re = if (ncx) ncxRe else navRe
            for (m in re.findAll(s)) {
                val title = clean(m.groupValues[if (ncx) 1 else 2])
                val src = m.groupValues[if (ncx) 2 else 1]
                if (title.isEmpty() || src.isEmpty() || src.startsWith("#")) continue
                val target = resolve(tbase + decode(src.substringBefore('#')))
                if (!titles.containsKey(target)) titles[target] = title
            }
        }
        for (item in manifest.values) {
            if (item.type == "application/x-dtbncx+xml") readToc(item, true)
        }
        for (item in manifest.values) {
            if (item.props.split(' ').contains("nav")) readToc(item, false)
        }

        val useToc = titles.isNotEmpty()
        val sb = StringBuilder()
        val chs = ArrayList<Chapter>()
        for (id in spine) {
            val item = manifest[id] ?: continue
            val path = resolve(base + decode(item.href.substringBefore('#')))
            val data = files[path] ?: continue
            val html = String(data, Charsets.UTF_8).replace(headRe, "").replace(scriptRe, "")
            val raw = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString()
            val off = append(sb, raw)
            if (off < 0) continue
            val tocTitle = titles[path]
            if (tocTitle != null) {
                chs.add(Chapter(off, tocTitle))
            } else if (!useToc) {
                val first = raw.lineSequence().map { it.trim { c -> isWs(c) } }.firstOrNull { it.isNotEmpty() } ?: ""
                chs.add(Chapter(off, first.take(24)))
            }
        }
        return finish(sb.toString(), chs)
    }

    /** 追加一段文字：去空行、段首缩进。返回这段的起始偏移，没有内容返回 -1 */
    private fun append(sb: StringBuilder, raw: String): Int {
        var start = -1
        for (line in raw.replace("\r", "").replace('\uFFFC', ' ').split('\n')) {
            val t = line.trim { isWs(it) }
            if (t.isEmpty()) continue
            if (sb.isNotEmpty()) sb.append('\n')
            if (start < 0) start = sb.length
            sb.append(INDENT).append(t)
        }
        return start
    }

    private fun clean(s: String): String =
        Html.fromHtml(tagRe.replace(s, ""), Html.FROM_HTML_MODE_LEGACY).toString()
            .replace(spaceRe, " ").trim()

    private fun decode(h: String): String = try {
        URLDecoder.decode(h.replace("+", "%2B"), "UTF-8")
    } catch (e: Exception) { h }

    private fun resolve(path: String): String {
        val out = ArrayList<String>()
        for (s in path.split('/')) {
            if (s == "" || s == ".") continue
            if (s == "..") { if (out.isNotEmpty()) out.removeAt(out.size - 1) } else out.add(s)
        }
        return out.joinToString("/")
    }

    private fun parse(data: ByteArray, onEvent: (XmlPullParser) -> Unit) {
        val p = XmlPullParserFactory.newInstance().newPullParser()
        p.setInput(ByteArrayInputStream(data), null)
        while (p.eventType != XmlPullParser.END_DOCUMENT) { onEvent(p); p.next() }
    }
}
