package com.example.einkreader

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class ShelfActivity : Activity() {
    private lateinit var shelf: Shelf
    private lateinit var listView: ListView
    private lateinit var empty: TextView
    private var books: List<Book> = emptyList()
    private val REQ_IMPORT = 1

    private val adapter = object : BaseAdapter() {
        override fun getCount() = books.size
        override fun getItem(i: Int): Any = books[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View = bookRow(books[i])
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        shelf = Shelf(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(WHITE)
            setPadding(dp(16), dp(24), dp(16), dp(8))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "书架"; textSize = 30f; typeface = Typeface.DEFAULT_BOLD; setTextColor(BLACK)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(TextView(this).apply {
            text = "＋ 导入"; textSize = 20f; setTextColor(BLACK); background = box(WHITE, BLACK, 3)
            setPadding(dp(18), dp(10), dp(18), dp(10))
            setOnClickListener { pickBooks() }
        })
        root.addView(header)
        root.addView(View(this).apply { setBackgroundColor(BLACK) },
            LinearLayout.LayoutParams(MATCH, 3).apply { topMargin = dp(12) })

        listView = ListView(this).apply {
            divider = ColorDrawable(0xFF999999.toInt()); dividerHeight = 2
            selector = ColorDrawable(Color.TRANSPARENT)
            this.adapter = this@ShelfActivity.adapter
            setOnItemClickListener { _, _, i, _ -> openBook(books[i]) }
            setOnItemLongClickListener { _, _, i, _ -> confirmDelete(books[i]); true }
        }
        empty = TextView(this).apply {
            text = "书架是空的\n点右上角「导入」添加 TXT / EPUB 书籍\n（可一次选多本）"
            textSize = 18f; gravity = Gravity.CENTER; setTextColor(0xFF444444.toInt())
        }
        val wrap = FrameLayout(this)
        wrap.addView(listView, FrameLayout.LayoutParams(MATCH, MATCH))
        wrap.addView(empty, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(wrap, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        books = shelf.list()
        adapter.notifyDataSetChanged()
        empty.visibility = if (books.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun bookRow(bk: Book): View {
        val pct = if (bk.len > 0) (bk.pos * 100L / bk.len).toInt().coerceIn(0, 100) else 0
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(12))
        }
        row.addView(TextView(this).apply {
            text = bk.title.take(1); textSize = 26f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(BLACK); background = box(WHITE, BLACK, 3)
        }, LinearLayout.LayoutParams(dp(56), dp(76)))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        col.addView(TextView(this).apply {
            text = bk.title; textSize = 20f; setTextColor(BLACK)
            maxLines = 2; ellipsize = TextUtils.TruncateAt.END
        })
        col.addView(TextView(this).apply {
            text = if (pct == 0) "未读" else "已读 $pct%"
            textSize = 15f; setTextColor(0xFF444444.toInt())
            setPadding(0, dp(4), 0, dp(6))
        })
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFFCCCCCC.toInt())
        }
        bar.addView(View(this).apply { setBackgroundColor(BLACK) }, LinearLayout.LayoutParams(0, MATCH, pct.toFloat()))
        bar.addView(View(this), LinearLayout.LayoutParams(0, MATCH, (100 - pct).toFloat()))
        col.addView(bar, LinearLayout.LayoutParams(MATCH, dp(6)))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        return row
    }

    private fun openBook(bk: Book) {
        startActivity(Intent(this, ReaderActivity::class.java).putExtra("id", bk.id))
    }

    private fun confirmDelete(bk: Book) {
        AlertDialog.Builder(this).setMessage("从书架删除《${bk.title}》？")
            .setPositiveButton("删除") { _, _ -> shelf.remove(bk.id); refresh() }
            .setNegativeButton("取消", null).show()
    }

    private fun pickBooks() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }, REQ_IMPORT)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req != REQ_IMPORT || res != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.clipData?.let { cd -> for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        Thread {
            var ok = 0
            for ((i, u) in uris.withIndex()) {
                runOnUiThread { toast("正在导入 ${i + 1}/${uris.size}…") }
                try {
                    val name = displayName(u) ?: "未命名"
                    val bytes = contentResolver.openInputStream(u)!!.use { it.readBytes() }
                    val parsed = BookLoader.load(bytes)
                    if (parsed.text.isEmpty()) throw Exception("没有可读文字")
                    shelf.addBook(name.substringBeforeLast('.'), parsed)
                    ok++
                } catch (e: Throwable) {
                    runOnUiThread { toast("导入失败：${e.message}") }
                }
            }
            runOnUiThread { refresh(); toast("已导入 $ok 本") }
        }.start()
    }
}
