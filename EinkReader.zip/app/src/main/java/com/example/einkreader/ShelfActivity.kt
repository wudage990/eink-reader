package com.example.einkreader

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.File

class ShelfActivity : Activity() {
    private lateinit var shelf: Shelf
    private lateinit var s: Settings
    private lateinit var listView: ListView
    private lateinit var gridView: GridView
    private lateinit var empty: TextView
    private lateinit var modeBtn: TextView
    private var books: List<Book> = emptyList()
    private val REQ_IMPORT = 1

    private val listAdapter = object : BaseAdapter() {
        override fun getCount() = books.size
        override fun getItem(i: Int): Any = books[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View = bookRow(books[i])
    }

    private val gridAdapter = object : BaseAdapter() {
        override fun getCount() = books.size
        override fun getItem(i: Int): Any = books[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View = gridCell(books[i], p)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        shelf = Shelf(this)
        s = Settings(this)
        applySavedOrientation(s)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(WHITE)
            setPadding(dp(16), dp(24), dp(16), dp(8))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "书架"; textSize = 28f; typeface = Typeface.DEFAULT_BOLD; setTextColor(BLACK)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        modeBtn = hbtn("图标") { s.shelfMode = 1 - s.shelfMode; applyMode() }
        header.addView(modeBtn, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        header.addView(hbtn("转屏") { toggleOrientation(s) }, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        header.addView(hbtn("＋导入") { pickBooks() })
        root.addView(header)
        root.addView(View(this).apply { setBackgroundColor(BLACK) },
            LinearLayout.LayoutParams(MATCH, 3).apply { topMargin = dp(12) })

        listView = ListView(this).apply {
            divider = ColorDrawable(0xFF999999.toInt()); dividerHeight = 2
            selector = ColorDrawable(Color.TRANSPARENT)
            this.adapter = listAdapter
            setOnItemClickListener { _, _, i, _ -> openBook(books[i]) }
            setOnItemLongClickListener { _, _, i, _ -> confirmDelete(books[i]); true }
        }
        gridView = GridView(this).apply {
            numColumns = 4
            horizontalSpacing = dp(6); verticalSpacing = dp(6)
            selector = ColorDrawable(Color.TRANSPARENT)
            this.adapter = gridAdapter
            setOnItemClickListener { _, _, i, _ -> openBook(books[i]) }
            setOnItemLongClickListener { _, _, i, _ -> confirmDelete(books[i]); true }
        }
        empty = TextView(this).apply {
            text = "书架是空的\n点右上角「＋导入」添加 TXT / EPUB 书籍\n（可一次选多本）"
            textSize = 18f; gravity = Gravity.CENTER; setTextColor(0xFF444444.toInt())
        }
        val wrap = FrameLayout(this)
        wrap.addView(listView, FrameLayout.LayoutParams(MATCH, MATCH))
        wrap.addView(gridView, FrameLayout.LayoutParams(MATCH, MATCH))
        wrap.addView(empty, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(wrap, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
        applyMode()
    }

    override fun onResume() {
        super.onResume()
        applySavedOrientation(s)
        refresh()
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        applyMode()
        refresh()
    }

    private fun hbtn(label: String, f: () -> Unit) = TextView(this).apply {
        text = label; textSize = 16f; setTextColor(BLACK); background = box(WHITE, BLACK, 3)
        setPadding(dp(12), dp(8), dp(12), dp(8))
        setOnClickListener { f() }
    }

    /** 列表 / 图标（一行 4 本，横屏 6 本） */
    private fun applyMode() {
        val grid = s.shelfMode == 1
        modeBtn.text = if (grid) "列表" else "图标"
        listView.visibility = if (grid) View.GONE else View.VISIBLE
        gridView.visibility = if (grid) View.VISIBLE else View.GONE
        gridView.numColumns =
            if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) 6 else 4
        gridAdapter.notifyDataSetChanged()
    }

    private fun refresh() {
        books = shelf.list()
        listAdapter.notifyDataSetChanged()
        gridAdapter.notifyDataSetChanged()
        empty.visibility = if (books.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun percent(bk: Book) =
        if (bk.len > 0) (bk.pos * 100L / bk.len).toInt().coerceIn(0, 100) else 0

    private fun progressBar(pct: Int): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFFCCCCCC.toInt())
        }
        bar.addView(View(this).apply { setBackgroundColor(BLACK) }, LinearLayout.LayoutParams(0, MATCH, pct.toFloat()))
        bar.addView(View(this), LinearLayout.LayoutParams(0, MATCH, (100 - pct).toFloat()))
        return bar
    }

    // ---- 列表样式 ----
    private fun bookRow(bk: Book): View {
        val pct = percent(bk)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(12))
        }
        row.addView(TextView(this).apply {
            text = bk.title.take(1); textSize = 26f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(BLACK); background = box(WHITE, BLACK, 3)
        }, LinearLayout.LayoutParams(dp(56), dp(76)))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        col.addView(TextView(this).apply {
            text = bk.title; textSize = 20f; setTextColor(BLACK)
            maxLines = 2; ellipsize = TextUtils.TruncateAt.END
        })
        col.addView(TextView(this).apply {
            text = if (pct == 0) "未读" else "已读 $pct%"
            textSize = 15f; setTextColor(0xFF444444.toInt())
            setPadding(0, dp(4), 0, dp(6))
        })
        col.addView(progressBar(pct), LinearLayout.LayoutParams(MATCH, dp(6)))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        return row
    }

    // ---- 图标样式 ----
    private fun gridCell(bk: Book, parent: ViewGroup?): View {
        val pct = percent(bk)
        val cols = max(1, gridView.numColumns)
        val total = if (parent != null && parent.width > 0) parent.width
            else resources.displayMetrics.widthPixels - dp(32)
        val cw = total / cols - dp(12)
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(3), dp(8), dp(3), dp(6))
        }
        val cover = FrameLayout(this).apply { background = box(WHITE, BLACK, 3) }
        cover.addView(TextView(this).apply {
            text = bk.title; textSize = 13f; setTextColor(BLACK); gravity = Gravity.CENTER
            maxLines = 5; ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(5), dp(6), dp(5), dp(12))
        }, FrameLayout.LayoutParams(MATCH, MATCH))
        cover.addView(progressBar(pct), FrameLayout.LayoutParams(MATCH, dp(5), Gravity.BOTTOM))
        cell.addView(cover, LinearLayout.LayoutParams(cw, (cw * 1.38f).toInt()))
        cell.addView(TextView(this).apply {
            text = if (pct == 0) "未读" else "$pct%"
            textSize = 12f; setTextColor(0xFF444444.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(3), 0, 0)
        })
        return cell
    }

    private fun max(a: Int, b: Int) = if (a > b) a else b

    private fun openBook(bk: Book) {
        startActivity(Intent(this, ReaderActivity::class.java).putExtra("id", bk.id))
    }

    private fun confirmDelete(bk: Book) {
        AlertDialog.Builder(this).setMessage("从书架删除《${bk.title}》？")
            .setPositiveButton("删除") { _, _ -> shelf.remove(bk.id); refresh() }
            .setNegativeButton("取消", null).show()
    }

    private fun pickBooks() {
        startActivityForResult(Intent(this, PickFileActivity::class.java)
            .putExtra("exts", arrayOf("epub", "txt"))
            .putExtra("multi", true), REQ_IMPORT)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req != REQ_IMPORT || res != RESULT_OK || data == null) return
        val paths = data.getStringArrayListExtra("paths") ?: return
        // 导入要解压、排版，需要一点时间，所以弹出进度框，不再只靠结束时的提示
        val dlg = AlertDialog.Builder(this).setMessage("正在导入…").setCancelable(false).create()
        dlg.show()
        Thread {
            var ok = 0
            val failed = ArrayList<String>()
            for ((i, path) in paths.withIndex()) {
                val f = File(path)
                runOnUiThread { dlg.setMessage("正在导入 ${i + 1}/${paths.size}\n${f.name}") }
                try {
                    val parsed = BookLoader.load(f.readBytes())
                    if (parsed.text.isEmpty()) throw Exception("没有可读文字")
                    shelf.addBook(f.nameWithoutExtension, parsed)
                    ok++
                } catch (e: Throwable) {
                    failed.add("${f.name}：${e.message}")
                }
            }
            runOnUiThread {
                dlg.dismiss()
                refresh()
                toast(if (failed.isEmpty()) "已导入 $ok 本" else "已导入 $ok 本，失败 ${failed.size} 本：${failed[0]}")
            }
        }.start()
    }
}
