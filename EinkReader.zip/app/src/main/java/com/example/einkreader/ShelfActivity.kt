package com.example.einkreader

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.File

class ShelfActivity : Activity() {
    /** 书架上的一项：要么是文件夹，要么是一本书 */
    private class Item(val folder: Folder?, val count: Int, val book: Book?)

    private lateinit var shelf: Shelf
    private lateinit var s: Settings
    private lateinit var listView: ListView
    private lateinit var gridView: GridView
    private lateinit var empty: TextView
    private lateinit var titleView: TextView
    private lateinit var modeBtn: TextView
    private lateinit var folderBtn: TextView
    private var books: List<Book> = emptyList()
    private var folders: List<Folder> = emptyList()
    private var items: List<Item> = emptyList()
    private var current = ""            // 当前所在文件夹的 id，空字符串 = 书架根目录
    private val REQ_IMPORT = 1

    private val listAdapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(i: Int): Any = items[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View {
            val it = items[i]
            val f = it.folder
            val bk = it.book
            return if (f != null) row("文件夹", 14f, f.name, "${it.count} 本书", -1)
            else row(fmtOf(bk!!), 15f, bk.title, readText(bk, "已读 "), percent(bk))
        }
    }

    private val gridAdapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(i: Int): Any = items[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View {
            val it = items[i]
            val f = it.folder
            val bk = it.book
            return if (f != null) cell(f.name, "文件夹", "${it.count} 本", -1, p)
            else cell(bk!!.title, fmtOf(bk), readText(bk, ""), percent(bk), p)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        shelf = Shelf(this)
        s = Settings(this)
        applySavedOrientation(s)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(WHITE)
            setPadding(dp(16), dp(24), dp(16), dp(8))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleView = TextView(this).apply {
            text = "书架"; textSize = 26f; typeface = Typeface.DEFAULT_BOLD; setTextColor(BLACK)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        header.addView(titleView, LinearLayout.LayoutParams(0, WRAP, 1f))
        modeBtn = hbtn("图标") { s.shelfMode = 1 - s.shelfMode; applyMode() }
        header.addView(modeBtn, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(6) })
        header.addView(hbtn("转屏") { toggleOrientation(s) }, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(6) })
        folderBtn = hbtn("＋文件夹") {
            if (current.isEmpty()) askName("新建文件夹", "") { n -> shelf.addFolder(n); refresh() }
            else { current = ""; refresh() }
        }
        header.addView(folderBtn, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(6) })
        header.addView(hbtn("＋导入") { pickBooks() })
        root.addView(header)
        root.addView(View(this).apply { setBackgroundColor(BLACK) },
            LinearLayout.LayoutParams(MATCH, 3).apply { topMargin = dp(12) })

        listView = ListView(this).apply {
            divider = ColorDrawable(0xFF999999.toInt()); dividerHeight = 2
            selector = ColorDrawable(Color.TRANSPARENT)
            this.adapter = listAdapter
            setOnItemClickListener { _, _, i, _ -> onItemClick(items[i]) }
            setOnItemLongClickListener { _, _, i, _ -> onItemLong(items[i]); true }
        }
        gridView = GridView(this).apply {
            numColumns = 4
            horizontalSpacing = dp(6); verticalSpacing = dp(6)
            selector = ColorDrawable(Color.TRANSPARENT)
            this.adapter = gridAdapter
            setOnItemClickListener { _, _, i, _ -> onItemClick(items[i]) }
            setOnItemLongClickListener { _, _, i, _ -> onItemLong(items[i]); true }
        }
        empty = TextView(this).apply {
            textSize = 18f; gravity = Gravity.CENTER; setTextColor(0xFF444444.toInt())
        }
        val wrap = FrameLayout(this)
        wrap.addView(listView, FrameLayout.LayoutParams(MATCH, MATCH))
        wrap.addView(gridView, FrameLayout.LayoutParams(MATCH, MATCH))
        wrap.addView(empty, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(wrap, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
        applyMode()
    }

    override fun onResume() {
        super.onResume()
        applySavedOrientation(s)
        refresh()
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        applyMode()
        refresh()
    }

    override fun onBackPressed() {
        if (current.isNotEmpty()) { current = ""; refresh() } else super.onBackPressed()
    }

    private fun hbtn(label: String, f: () -> Unit) = TextView(this).apply {
        text = label; textSize = 15f; setTextColor(BLACK); background = box(WHITE, BLACK, 3)
        setPadding(dp(10), dp(8), dp(10), dp(8))
        setOnClickListener { f() }
    }

    /** 列表 / 图标（一行 4 本，横屏 6 本） */
    private fun applyMode() {
        val grid = s.shelfMode == 1
        modeBtn.text = if (grid) "列表" else "图标"
        listView.visibility = if (grid) View.GONE else View.VISIBLE
        gridView.visibility = if (grid) View.VISIBLE else View.GONE
        gridView.numColumns =
            if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) 6 else 4
        gridAdapter.notifyDataSetChanged()
    }

    private fun refresh() {
        books = shelf.list()
        folders = shelf.folders().sortedBy { it.name }
        if (current.isNotEmpty() && folders.none { it.id == current }) current = ""
        items = if (current.isEmpty()) {
            folders.map { f -> Item(f, books.count { it.folder == f.id }, null) } +
                books.filter { b -> folders.none { it.id == b.folder } }.map { Item(null, 0, it) }
        } else {
            books.filter { it.folder == current }.map { Item(null, 0, it) }
        }
        titleView.text = if (current.isEmpty()) "书架" else "书架 › " + folders.first { it.id == current }.name
        folderBtn.text = if (current.isEmpty()) "＋文件夹" else "返回"
        empty.text = if (current.isEmpty())
            "书架是空的\n点右上角「＋导入」添加 TXT / EPUB 书籍\n（可一次选多本）\n用「＋文件夹」可以给书分类"
        else
            "这个文件夹还是空的\n在这里点「＋导入」，或回到书架长按一本书选「移到文件夹」"
        listAdapter.notifyDataSetChanged()
        gridAdapter.notifyDataSetChanged()
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    // ---------------- 显示 ----------------
    private fun fmtOf(bk: Book) = if (bk.fmt.isEmpty()) "BOOK" else bk.fmt.uppercase()

    private fun percent(bk: Book) =
        if (bk.len > 0) (bk.pos * 100L / bk.len).toInt().coerceIn(0, 100) else 0

    private fun readText(bk: Book, prefix: String): String {
        val pct = percent(bk)
        return if (pct == 0) "未读" else "$prefix$pct%"
    }

    private fun progressBar(pct: Int): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFFCCCCCC.toInt())
        }
        bar.addView(View(this).apply { setBackgroundColor(BLACK) }, LinearLayout.LayoutParams(0, MATCH, pct.toFloat()))
        bar.addView(View(this), LinearLayout.LayoutParams(0, MATCH, (100 - pct).toFloat()))
        return bar
    }

    /** 列表样式。pct < 0 表示不显示进度条（文件夹） */
    private fun row(block: String, blockSize: Float, title: String, sub: String, pct: Int): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(12))
        }
        row.addView(TextView(this).apply {
            text = block; textSize = blockSize; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(BLACK); background = box(WHITE, BLACK, 3)
        }, LinearLayout.LayoutParams(dp(56), dp(76)))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        col.addView(TextView(this).apply {
            text = title; textSize = 20f; setTextColor(BLACK)
            maxLines = 2; ellipsize = TextUtils.TruncateAt.END
        })
        col.addView(TextView(this).apply {
            text = sub; textSize = 15f; setTextColor(0xFF444444.toInt())
            setPadding(0, dp(4), 0, dp(6))
        })
        if (pct >= 0) col.addView(progressBar(pct), LinearLayout.LayoutParams(MATCH, dp(6)))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        return row
    }

    /** 图标样式：封面 + 右上角角标 + 下方文字 */
    private fun cell(title: String, badge: String, sub: String, pct: Int, parent: ViewGroup?): View {
        val cols = if (gridView.numColumns < 1) 1 else gridView.numColumns
        val total = if (parent != null && parent.width > 0) parent.width
            else resources.displayMetrics.widthPixels - dp(32)
        val cw = total / cols - dp(12)
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(3), dp(8), dp(3), dp(6))
        }
        val cover = FrameLayout(this).apply { background = box(WHITE, BLACK, 3) }
        cover.addView(TextView(this).apply {
            text = title; textSize = 13f; setTextColor(BLACK); gravity = Gravity.CENTER
            maxLines = 5; ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(5), dp(6), dp(5), dp(12))
        }, FrameLayout.LayoutParams(MATCH, MATCH))
        if (pct >= 0) cover.addView(progressBar(pct), FrameLayout.LayoutParams(MATCH, dp(5), Gravity.BOTTOM))
        cover.addView(TextView(this).apply {
            text = badge; textSize = 10f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(WHITE); setBackgroundColor(BLACK)
            setPadding(dp(4), dp(1), dp(4), dp(1))
        }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END))
        cell.addView(cover, LinearLayout.LayoutParams(cw, (cw * 1.38f).toInt()))
        cell.addView(TextView(this).apply {
            text = sub; textSize = 12f; setTextColor(0xFF444444.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(3), 0, 0)
        })
        return cell
    }

    // ---------------- 点击 / 长按 ----------------
    private fun onItemClick(it: Item) {
        val f = it.folder
        if (f != null) { current = f.id; refresh() }
        else startActivity(Intent(this, ReaderActivity::class.java).putExtra("id", it.book!!.id))
    }

    private fun onItemLong(it: Item) {
        val f = it.folder
        if (f != null) folderMenu(f) else bookMenu(it.book!!)
    }

    private fun bookMenu(bk: Book) {
        val size = humanSize(shelf.textFile(bk.id).length())
        AlertDialog.Builder(this).setTitle(bk.title)
            .setItems(arrayOf("移到文件夹…", "从书架删除（释放 $size）")) { _, i ->
                if (i == 0) moveDialog(bk) else confirmDelete(bk)
            }.show()
    }

    private fun folderMenu(f: Folder) {
        AlertDialog.Builder(this).setTitle(f.name)
            .setItems(arrayOf("重命名", "删除文件夹（里面的书回到书架）")) { _, i ->
                if (i == 0) askName("重命名", f.name) { n -> shelf.renameFolder(f.id, n); refresh() }
                else AlertDialog.Builder(this).setMessage("删除文件夹「${f.name}」？里面的书不会被删除，会回到书架。")
                    .setPositiveButton("删除") { _, _ -> shelf.removeFolder(f.id); refresh() }
                    .setNegativeButton("取消", null).show()
            }.show()
    }

    private fun moveDialog(bk: Book) {
        val names = ArrayList<String>()
        val ids = ArrayList<String>()
        names.add("书架（不放进文件夹）"); ids.add("")
        for (f in folders) { names.add(f.name); ids.add(f.id) }
        names.add("＋ 新建文件夹并移入…")
        AlertDialog.Builder(this).setTitle("移到…")
            .setItems(names.toTypedArray()) { _, i ->
                if (i == names.size - 1) {
                    askName("新建文件夹", "") { n ->
                        val id = shelf.addFolder(n)
                        shelf.moveBook(bk.id, id)
                        refresh()
                    }
                } else {
                    shelf.moveBook(bk.id, ids[i])
                    refresh()
                }
            }.show()
    }

    private fun askName(title: String, initial: String, onOk: (String) -> Unit) {
        val et = EditText(this)
        et.setText(initial)
        et.setSingleLine(true)
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("确定") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) onOk(n)
            }.setNegativeButton("取消", null).show()
    }

    private fun confirmDelete(bk: Book) {
        AlertDialog.Builder(this)
            .setMessage("从书架删除《${bk.title}》？\n只会删除应用里解析出来的文字，你存储里的原文件不受影响。")
            .setPositiveButton("删除") { _, _ -> shelf.remove(bk.id); refresh() }
            .setNegativeButton("取消", null).show()
    }

    // ---------------- 导入 ----------------
    private fun pickBooks() {
        startActivityForResult(Intent(this, PickFileActivity::class.java)
            .putExtra("exts", arrayOf("epub", "txt"))
            .putExtra("multi", true), REQ_IMPORT)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req != REQ_IMPORT || res != RESULT_OK || data == null) return
        val paths = data.getStringArrayListExtra("paths") ?: return
        val target = current                // 导入到当前所在的文件夹
        val dlg = AlertDialog.Builder(this).setMessage("正在导入…").setCancelable(false).create()
        dlg.show()
        Thread {
            var ok = 0
            val failed = ArrayList<String>()
            for ((i, path) in paths.withIndex()) {
                val f = File(path)
                val head = "正在导入 ${i + 1}/${paths.size}\n${f.name}"
                runOnUiThread { dlg.setMessage(head) }
                val id = shelf.newId()
                try {
                    val res2 = BookLoader.importBook(f, shelf.textFile(id)) { pct ->
                        runOnUiThread { dlg.setMessage("$head\n$pct%") }
                    }
                    if (res2.length == 0) throw Exception("没有可读文字")
                    shelf.register(id, f.nameWithoutExtension, res2.length, f.extension.uppercase(), target, res2.chapters)
                    ok++
                } catch (e: Throwable) {
                    shelf.textFile(id).delete()
                    failed.add("${f.name}：${e.message ?: e.javaClass.simpleName}")
                }
            }
            runOnUiThread {
                dlg.dismiss()
                refresh()
                toast(if (failed.isEmpty()) "已导入 $ok 本" else "已导入 $ok 本，失败 ${failed.size} 本：${failed[0]}")
            }
        }.start()
    }
}
